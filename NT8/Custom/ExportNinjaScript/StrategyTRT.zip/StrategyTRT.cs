#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private GIAwesomeOscillator[] cacheGIAwesomeOscillator;
		private GISMI[] cacheGISMI;
		private SMI[] cacheSMI;

		
		public GIAwesomeOscillator GIAwesomeOscillator(int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType)
		{
			return GIAwesomeOscillator(Input, fastPeriod, slowPeriod, smooth, movingAverageType);
		}

		public GISMI GISMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return GISMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

		public SMI SMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return SMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}


		
		public GIAwesomeOscillator GIAwesomeOscillator(ISeries<double> input, int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType)
		{
			if (cacheGIAwesomeOscillator != null)
				for (int idx = 0; idx < cacheGIAwesomeOscillator.Length; idx++)
					if (cacheGIAwesomeOscillator[idx].FastPeriod == fastPeriod && cacheGIAwesomeOscillator[idx].SlowPeriod == slowPeriod && cacheGIAwesomeOscillator[idx].Smooth == smooth && cacheGIAwesomeOscillator[idx].MovingAverageType == movingAverageType && cacheGIAwesomeOscillator[idx].EqualsInput(input))
						return cacheGIAwesomeOscillator[idx];
			return CacheIndicator<GIAwesomeOscillator>(new GIAwesomeOscillator(){ FastPeriod = fastPeriod, SlowPeriod = slowPeriod, Smooth = smooth, MovingAverageType = movingAverageType }, input, ref cacheGIAwesomeOscillator);
		}

		public GISMI GISMI(ISeries<double> input, int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			if (cacheGISMI != null)
				for (int idx = 0; idx < cacheGISMI.Length; idx++)
					if (cacheGISMI[idx].EMAPeriod1 == eMAPeriod1 && cacheGISMI[idx].EMAPeriod2 == eMAPeriod2 && cacheGISMI[idx].Range == range && cacheGISMI[idx].SMITMAPeriod == sMITMAPeriod && cacheGISMI[idx].EqualsInput(input))
						return cacheGISMI[idx];
			return CacheIndicator<GISMI>(new GISMI(){ EMAPeriod1 = eMAPeriod1, EMAPeriod2 = eMAPeriod2, Range = range, SMITMAPeriod = sMITMAPeriod }, input, ref cacheGISMI);
		}

		public SMI SMI(ISeries<double> input, int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			if (cacheSMI != null)
				for (int idx = 0; idx < cacheSMI.Length; idx++)
					if (cacheSMI[idx].EMAPeriod1 == eMAPeriod1 && cacheSMI[idx].EMAPeriod2 == eMAPeriod2 && cacheSMI[idx].Range == range && cacheSMI[idx].SMITMAPeriod == sMITMAPeriod && cacheSMI[idx].EqualsInput(input))
						return cacheSMI[idx];
			return CacheIndicator<SMI>(new SMI(){ EMAPeriod1 = eMAPeriod1, EMAPeriod2 = eMAPeriod2, Range = range, SMITMAPeriod = sMITMAPeriod }, input, ref cacheSMI);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.GIAwesomeOscillator GIAwesomeOscillator(int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType)
		{
			return indicator.GIAwesomeOscillator(Input, fastPeriod, slowPeriod, smooth, movingAverageType);
		}

		public Indicators.GISMI GISMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.GISMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

		public Indicators.SMI SMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.SMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}


		
		public Indicators.GIAwesomeOscillator GIAwesomeOscillator(ISeries<double> input , int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType)
		{
			return indicator.GIAwesomeOscillator(input, fastPeriod, slowPeriod, smooth, movingAverageType);
		}

		public Indicators.GISMI GISMI(ISeries<double> input , int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.GISMI(input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

		public Indicators.SMI SMI(ISeries<double> input , int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.SMI(input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.GIAwesomeOscillator GIAwesomeOscillator(int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType)
		{
			return indicator.GIAwesomeOscillator(Input, fastPeriod, slowPeriod, smooth, movingAverageType);
		}

		public Indicators.GISMI GISMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.GISMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

		public Indicators.SMI SMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.SMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}


		
		public Indicators.GIAwesomeOscillator GIAwesomeOscillator(ISeries<double> input , int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType)
		{
			return indicator.GIAwesomeOscillator(input, fastPeriod, slowPeriod, smooth, movingAverageType);
		}

		public Indicators.GISMI GISMI(ISeries<double> input , int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.GISMI(input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

		public Indicators.SMI SMI(ISeries<double> input , int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.SMI(input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

	}
}

#endregion
