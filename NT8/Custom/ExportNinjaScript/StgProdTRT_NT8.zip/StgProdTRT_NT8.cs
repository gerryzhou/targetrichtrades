#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private GIAwesomeOscillator[] cacheGIAwesomeOscillator;
		private GIEMA[] cacheGIEMA;
		private GIFibonacci[] cacheGIFibonacci;
		private GIGetHighLowByPeriod[] cacheGIGetHighLowByPeriod;
		private GIGetHighLowByTimeRange[] cacheGIGetHighLowByTimeRange;
		private GIHLnBars[] cacheGIHLnBars;
		private GIKAMA[] cacheGIKAMA;
		private GIKeyReversal[] cacheGIKeyReversal;
		private GIMktCtx[] cacheGIMktCtx;
		private GINBarsUpDn[] cacheGINBarsUpDn;
		private GINetChg[] cacheGINetChg;
		private GIPbSAR[] cacheGIPbSAR;
		private GIPctSpd[] cacheGIPctSpd;
		private GIPriorMonthOHLC[] cacheGIPriorMonthOHLC;
		private GIPriorWeekOHLC[] cacheGIPriorWeekOHLC;
		private GISMI[] cacheGISMI;
		private GISnR[] cacheGISnR;
		private GISnRPriorWM[] cacheGISnRPriorWM;
		private GIVOL[] cacheGIVOL;
		private GIVWAP[] cacheGIVWAP;
		private SMI[] cacheSMI;
		private PriceActionSwing.PriceActionSwing[] cachePriceActionSwing;
		private PriceActionSwing.PriceActionSwingOscillator[] cachePriceActionSwingOscillator;
		private PriceActionSwing.PriceActionSwingPro[] cachePriceActionSwingPro;
		private ZTraderInd.GIndicatorProxy[] cacheGIndicatorProxy;

		
		public GIAwesomeOscillator GIAwesomeOscillator(int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType, bool showLines)
		{
			return GIAwesomeOscillator(Input, fastPeriod, slowPeriod, smooth, movingAverageType, showLines);
		}

		public GIEMA GIEMA(int period, int offsetTicks)
		{
			return GIEMA(Input, period, offsetTicks);
		}

		public GIFibonacci GIFibonacci(int param1)
		{
			return GIFibonacci(Input, param1);
		}

		public GIGetHighLowByPeriod GIGetHighLowByPeriod(SignalBarByType periodStartBy, SignalBarByType periodEndBy, int startHour, int startMinute, int endHour, int endMinute)
		{
			return GIGetHighLowByPeriod(Input, periodStartBy, periodEndBy, startHour, startMinute, endHour, endMinute);
		}

		public GIGetHighLowByTimeRange GIGetHighLowByTimeRange(int startHour, int startMinute, int endHour, int endMinute)
		{
			return GIGetHighLowByTimeRange(Input, startHour, startMinute, endHour, endMinute);
		}

		public GIHLnBars GIHLnBars(int period)
		{
			return GIHLnBars(Input, period);
		}

		public GIKAMA GIKAMA(int fast, int period, int slow)
		{
			return GIKAMA(Input, fast, period, slow);
		}

		public GIKeyReversal GIKeyReversal(int periodLeft, int periodRight)
		{
			return GIKeyReversal(Input, periodLeft, periodRight);
		}

		public GIMktCtx GIMktCtx(int ctxFilePath)
		{
			return GIMktCtx(Input, ctxFilePath);
		}

		public GINBarsUpDn GINBarsUpDn(int barCount, bool barUp, bool higherHigh, bool higherLow, bool barDown, bool lowerHigh, bool lowerLow)
		{
			return GINBarsUpDn(Input, barCount, barUp, higherHigh, higherLow, barDown, lowerHigh, lowerLow);
		}

		public GINetChg GINetChg(Cbi.PerformanceUnit unit, NetChgPosition location)
		{
			return GINetChg(Input, unit, location);
		}

		public GIPbSAR GIPbSAR(double acceleration, double accelerationMax, double accelerationStep)
		{
			return GIPbSAR(Input, acceleration, accelerationMax, accelerationStep);
		}

		public GIPctSpd GIPctSpd(int rocPeriod)
		{
			return GIPctSpd(Input, rocPeriod);
		}

		public GIPriorMonthOHLC GIPriorMonthOHLC()
		{
			return GIPriorMonthOHLC(Input);
		}

		public GIPriorWeekOHLC GIPriorWeekOHLC()
		{
			return GIPriorWeekOHLC(Input);
		}

		public GISMI GISMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod, int sMICrossLevel)
		{
			return GISMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod, sMICrossLevel);
		}

		public GISnR GISnR(bool showOvernightHL, bool showOpenHL, bool showLastdayHL, bool showLastdayClose, bool showTodayOpen, int timeOpen, int timeClose)
		{
			return GISnR(Input, showOvernightHL, showOpenHL, showLastdayHL, showLastdayClose, showTodayOpen, timeOpen, timeClose);
		}

		public GISnRPriorWM GISnRPriorWM(bool showWkClose, bool showWkHigh, bool showWkLow, bool showWkOpen, bool showMoClose, bool showMoHigh, bool showMoLow, bool showMoOpen)
		{
			return GISnRPriorWM(Input, showWkClose, showWkHigh, showWkLow, showWkOpen, showMoClose, showMoHigh, showMoLow, showMoOpen);
		}

		public GIVOL GIVOL(int volPeriod, int volWPRPeriod)
		{
			return GIVOL(Input, volPeriod, volWPRPeriod);
		}

		public GIVWAP GIVWAP()
		{
			return GIVWAP(Input);
		}

		public SMI SMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return SMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

		public PriceActionSwing.PriceActionSwing PriceActionSwing(SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool ignoreInsideBars, bool useBreakouts)
		{
			return PriceActionSwing(Input, swingType, swingSize, dtbStrength, useCloseValues, swingLengthType, swingDurationType, showSwingPrice, showSwingLabel, showSwingPercent, swingTimeType, swingVolumeType, visualizationType, textFont, textOffsetLength, textOffsetVolume, textOffsetPrice, textOffsetLabel, textOffsetTime, textOffsetPercent, zigZagStyle, zigZagWidth, ignoreInsideBars, useBreakouts);
		}

		public PriceActionSwing.PriceActionSwingOscillator PriceActionSwingOscillator(SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, Show showOscillator, bool useOldTrend, bool ignoreInsideBars, bool useBreakouts)
		{
			return PriceActionSwingOscillator(Input, swingType, swingSize, dtbStrength, useCloseValues, showOscillator, useOldTrend, ignoreInsideBars, useBreakouts);
		}

		public PriceActionSwing.PriceActionSwingPro PriceActionSwingPro(SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, AbcPatternMode abcPattern, DivergenceMode divergenceIndicatorMode, DivergenceDirection divergenceDirectionMode, int param1, int param2, int param3, bool showNakedSwings, bool addSwingExtension, bool addSwingRetracementFast, bool addSwingRetracementSlow, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool showSwingSwitch, int swingSwitchOffsetInTicks, DashStyleHelper abcLineStyle, DashStyleHelper abcLineStyleRatio, int abcLineWidth, int abcLineWidthRatio, NinjaTrader.Gui.Tools.SimpleFont abcTextFont, int abcTextOffsetLabel, double abcMaxRetracement, double abcMinRetracement, DashStyleHelper entryLineStyle, int entryLineWidth, double retracementEntryValue, bool showEntryArrows, bool showHistoricalEntryLine, int yTickOffset, bool showDivergenceRegular, bool showDivergenceHidden, DashStyleHelper divDnLineStyle, DashStyleHelper divUpLineStyle, int divDnLineWidth, int divUpLineWidth, bool showHistoricalNakedSwings, DashStyleHelper nakedSwingDashStyle, int nakedSwingLineWidth, bool ignoreInsideBars, bool useBreakouts, bool alertAbc, bool alertAbcEntry, Priority alertAbcPriority, Priority alertAbcEntryPriority, string alertAbcLongSoundFileName, string alertAbcLongEntrySoundFileName, string alertAbcShortSoundFileName, string alertAbcShortEntrySoundFileName, bool alertDoubleBottom, Priority alertDoubleBottomPriority, string alertDoubleBottomMessage, string alertDoubleBottomSoundFileName, int alertDoubleBottomRearmSeconds, bool alertDoubleTop, Priority alertDoubleTopPriority, string alertDoubleTopMessage, string alertDoubleTopSoundFileName, int alertDoubleTopRearmSeconds, bool alertHigherLow, Priority alertHigherLowPriority, string alertHigherLowMessage, string alertHigherLowSoundFileName, int alertHigherLowRearmSeconds, bool alertLowerHigh, Priority alertLowerHighPriority, string alertLowerHighMessage, string alertLowerHighSoundFileName, int alertLowerHighRearmSeconds, bool alertSwingChange, Priority alertSwingChangePriority, string alertSwingChangeMessage, string alertSwingChangeSoundFileName, int alertSwingChangeRearmSeconds, bool alertDivergenceRegularHigh, Priority alertDivergenceRegularHighPriority, string alertDivergenceRegularHighMessage, string alertDivergenceRegularHighSoundFileName, int alertDivergenceRegularHighRearmSeconds, bool alertDivergenceHiddenHigh, Priority alertDivergenceHiddenHighPriority, string alertDivergenceHiddenHighMessage, string alertDivergenceHiddenHighSoundFileName, int alertDivergenceHiddenHighRearmSeconds, bool alertDivergenceRegularLow, Priority alertDivergenceRegularLowPriority, string alertDivergenceRegularLowMessage, string alertDivergenceRegularLowSoundFileName, int alertDivergenceRegularLowRearmSeconds, bool alertDivergenceHiddenLow, Priority alertDivergenceHiddenLowPriority, string alertDivergenceHiddenLowMessage, string alertDivergenceHiddenLowSoundFileName, int alertDivergenceHiddenLowRearmSeconds)
		{
			return PriceActionSwingPro(Input, swingType, swingSize, dtbStrength, useCloseValues, abcPattern, divergenceIndicatorMode, divergenceDirectionMode, param1, param2, param3, showNakedSwings, addSwingExtension, addSwingRetracementFast, addSwingRetracementSlow, swingLengthType, swingDurationType, showSwingPrice, showSwingLabel, showSwingPercent, swingTimeType, swingVolumeType, visualizationType, textFont, textOffsetLength, textOffsetVolume, textOffsetPrice, textOffsetLabel, textOffsetTime, textOffsetPercent, zigZagStyle, zigZagWidth, showSwingSwitch, swingSwitchOffsetInTicks, abcLineStyle, abcLineStyleRatio, abcLineWidth, abcLineWidthRatio, abcTextFont, abcTextOffsetLabel, abcMaxRetracement, abcMinRetracement, entryLineStyle, entryLineWidth, retracementEntryValue, showEntryArrows, showHistoricalEntryLine, yTickOffset, showDivergenceRegular, showDivergenceHidden, divDnLineStyle, divUpLineStyle, divDnLineWidth, divUpLineWidth, showHistoricalNakedSwings, nakedSwingDashStyle, nakedSwingLineWidth, ignoreInsideBars, useBreakouts, alertAbc, alertAbcEntry, alertAbcPriority, alertAbcEntryPriority, alertAbcLongSoundFileName, alertAbcLongEntrySoundFileName, alertAbcShortSoundFileName, alertAbcShortEntrySoundFileName, alertDoubleBottom, alertDoubleBottomPriority, alertDoubleBottomMessage, alertDoubleBottomSoundFileName, alertDoubleBottomRearmSeconds, alertDoubleTop, alertDoubleTopPriority, alertDoubleTopMessage, alertDoubleTopSoundFileName, alertDoubleTopRearmSeconds, alertHigherLow, alertHigherLowPriority, alertHigherLowMessage, alertHigherLowSoundFileName, alertHigherLowRearmSeconds, alertLowerHigh, alertLowerHighPriority, alertLowerHighMessage, alertLowerHighSoundFileName, alertLowerHighRearmSeconds, alertSwingChange, alertSwingChangePriority, alertSwingChangeMessage, alertSwingChangeSoundFileName, alertSwingChangeRearmSeconds, alertDivergenceRegularHigh, alertDivergenceRegularHighPriority, alertDivergenceRegularHighMessage, alertDivergenceRegularHighSoundFileName, alertDivergenceRegularHighRearmSeconds, alertDivergenceHiddenHigh, alertDivergenceHiddenHighPriority, alertDivergenceHiddenHighMessage, alertDivergenceHiddenHighSoundFileName, alertDivergenceHiddenHighRearmSeconds, alertDivergenceRegularLow, alertDivergenceRegularLowPriority, alertDivergenceRegularLowMessage, alertDivergenceRegularLowSoundFileName, alertDivergenceRegularLowRearmSeconds, alertDivergenceHiddenLow, alertDivergenceHiddenLowPriority, alertDivergenceHiddenLowMessage, alertDivergenceHiddenLowSoundFileName, alertDivergenceHiddenLowRearmSeconds);
		}

		public ZTraderInd.GIndicatorProxy GIndicatorProxy(GStrategyBase gSZTrader)
		{
			return GIndicatorProxy(Input, gSZTrader);
		}


		
		public GIAwesomeOscillator GIAwesomeOscillator(ISeries<double> input, int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType, bool showLines)
		{
			if (cacheGIAwesomeOscillator != null)
				for (int idx = 0; idx < cacheGIAwesomeOscillator.Length; idx++)
					if (cacheGIAwesomeOscillator[idx].FastPeriod == fastPeriod && cacheGIAwesomeOscillator[idx].SlowPeriod == slowPeriod && cacheGIAwesomeOscillator[idx].Smooth == smooth && cacheGIAwesomeOscillator[idx].MovingAverageType == movingAverageType && cacheGIAwesomeOscillator[idx].ShowLines == showLines && cacheGIAwesomeOscillator[idx].EqualsInput(input))
						return cacheGIAwesomeOscillator[idx];
			return CacheIndicator<GIAwesomeOscillator>(new GIAwesomeOscillator(){ FastPeriod = fastPeriod, SlowPeriod = slowPeriod, Smooth = smooth, MovingAverageType = movingAverageType, ShowLines = showLines }, input, ref cacheGIAwesomeOscillator);
		}

		public GIEMA GIEMA(ISeries<double> input, int period, int offsetTicks)
		{
			if (cacheGIEMA != null)
				for (int idx = 0; idx < cacheGIEMA.Length; idx++)
					if (cacheGIEMA[idx].Period == period && cacheGIEMA[idx].OffsetTicks == offsetTicks && cacheGIEMA[idx].EqualsInput(input))
						return cacheGIEMA[idx];
			return CacheIndicator<GIEMA>(new GIEMA(){ Period = period, OffsetTicks = offsetTicks }, input, ref cacheGIEMA);
		}

		public GIFibonacci GIFibonacci(ISeries<double> input, int param1)
		{
			if (cacheGIFibonacci != null)
				for (int idx = 0; idx < cacheGIFibonacci.Length; idx++)
					if (cacheGIFibonacci[idx].Param1 == param1 && cacheGIFibonacci[idx].EqualsInput(input))
						return cacheGIFibonacci[idx];
			return CacheIndicator<GIFibonacci>(new GIFibonacci(){ Param1 = param1 }, input, ref cacheGIFibonacci);
		}

		public GIGetHighLowByPeriod GIGetHighLowByPeriod(ISeries<double> input, SignalBarByType periodStartBy, SignalBarByType periodEndBy, int startHour, int startMinute, int endHour, int endMinute)
		{
			if (cacheGIGetHighLowByPeriod != null)
				for (int idx = 0; idx < cacheGIGetHighLowByPeriod.Length; idx++)
					if (cacheGIGetHighLowByPeriod[idx].PeriodStartBy == periodStartBy && cacheGIGetHighLowByPeriod[idx].PeriodEndBy == periodEndBy && cacheGIGetHighLowByPeriod[idx].StartHour == startHour && cacheGIGetHighLowByPeriod[idx].StartMinute == startMinute && cacheGIGetHighLowByPeriod[idx].EndHour == endHour && cacheGIGetHighLowByPeriod[idx].EndMinute == endMinute && cacheGIGetHighLowByPeriod[idx].EqualsInput(input))
						return cacheGIGetHighLowByPeriod[idx];
			return CacheIndicator<GIGetHighLowByPeriod>(new GIGetHighLowByPeriod(){ PeriodStartBy = periodStartBy, PeriodEndBy = periodEndBy, StartHour = startHour, StartMinute = startMinute, EndHour = endHour, EndMinute = endMinute }, input, ref cacheGIGetHighLowByPeriod);
		}

		public GIGetHighLowByTimeRange GIGetHighLowByTimeRange(ISeries<double> input, int startHour, int startMinute, int endHour, int endMinute)
		{
			if (cacheGIGetHighLowByTimeRange != null)
				for (int idx = 0; idx < cacheGIGetHighLowByTimeRange.Length; idx++)
					if (cacheGIGetHighLowByTimeRange[idx].StartHour == startHour && cacheGIGetHighLowByTimeRange[idx].StartMinute == startMinute && cacheGIGetHighLowByTimeRange[idx].EndHour == endHour && cacheGIGetHighLowByTimeRange[idx].EndMinute == endMinute && cacheGIGetHighLowByTimeRange[idx].EqualsInput(input))
						return cacheGIGetHighLowByTimeRange[idx];
			return CacheIndicator<GIGetHighLowByTimeRange>(new GIGetHighLowByTimeRange(){ StartHour = startHour, StartMinute = startMinute, EndHour = endHour, EndMinute = endMinute }, input, ref cacheGIGetHighLowByTimeRange);
		}

		public GIHLnBars GIHLnBars(ISeries<double> input, int period)
		{
			if (cacheGIHLnBars != null)
				for (int idx = 0; idx < cacheGIHLnBars.Length; idx++)
					if (cacheGIHLnBars[idx].Period == period && cacheGIHLnBars[idx].EqualsInput(input))
						return cacheGIHLnBars[idx];
			return CacheIndicator<GIHLnBars>(new GIHLnBars(){ Period = period }, input, ref cacheGIHLnBars);
		}

		public GIKAMA GIKAMA(ISeries<double> input, int fast, int period, int slow)
		{
			if (cacheGIKAMA != null)
				for (int idx = 0; idx < cacheGIKAMA.Length; idx++)
					if (cacheGIKAMA[idx].Fast == fast && cacheGIKAMA[idx].Period == period && cacheGIKAMA[idx].Slow == slow && cacheGIKAMA[idx].EqualsInput(input))
						return cacheGIKAMA[idx];
			return CacheIndicator<GIKAMA>(new GIKAMA(){ Fast = fast, Period = period, Slow = slow }, input, ref cacheGIKAMA);
		}

		public GIKeyReversal GIKeyReversal(ISeries<double> input, int periodLeft, int periodRight)
		{
			if (cacheGIKeyReversal != null)
				for (int idx = 0; idx < cacheGIKeyReversal.Length; idx++)
					if (cacheGIKeyReversal[idx].PeriodLeft == periodLeft && cacheGIKeyReversal[idx].PeriodRight == periodRight && cacheGIKeyReversal[idx].EqualsInput(input))
						return cacheGIKeyReversal[idx];
			return CacheIndicator<GIKeyReversal>(new GIKeyReversal(){ PeriodLeft = periodLeft, PeriodRight = periodRight }, input, ref cacheGIKeyReversal);
		}

		public GIMktCtx GIMktCtx(ISeries<double> input, int ctxFilePath)
		{
			if (cacheGIMktCtx != null)
				for (int idx = 0; idx < cacheGIMktCtx.Length; idx++)
					if (cacheGIMktCtx[idx].CtxFilePath == ctxFilePath && cacheGIMktCtx[idx].EqualsInput(input))
						return cacheGIMktCtx[idx];
			return CacheIndicator<GIMktCtx>(new GIMktCtx(){ CtxFilePath = ctxFilePath }, input, ref cacheGIMktCtx);
		}

		public GINBarsUpDn GINBarsUpDn(ISeries<double> input, int barCount, bool barUp, bool higherHigh, bool higherLow, bool barDown, bool lowerHigh, bool lowerLow)
		{
			if (cacheGINBarsUpDn != null)
				for (int idx = 0; idx < cacheGINBarsUpDn.Length; idx++)
					if (cacheGINBarsUpDn[idx].BarCount == barCount && cacheGINBarsUpDn[idx].BarUp == barUp && cacheGINBarsUpDn[idx].HigherHigh == higherHigh && cacheGINBarsUpDn[idx].HigherLow == higherLow && cacheGINBarsUpDn[idx].BarDown == barDown && cacheGINBarsUpDn[idx].LowerHigh == lowerHigh && cacheGINBarsUpDn[idx].LowerLow == lowerLow && cacheGINBarsUpDn[idx].EqualsInput(input))
						return cacheGINBarsUpDn[idx];
			return CacheIndicator<GINBarsUpDn>(new GINBarsUpDn(){ BarCount = barCount, BarUp = barUp, HigherHigh = higherHigh, HigherLow = higherLow, BarDown = barDown, LowerHigh = lowerHigh, LowerLow = lowerLow }, input, ref cacheGINBarsUpDn);
		}

		public GINetChg GINetChg(ISeries<double> input, Cbi.PerformanceUnit unit, NetChgPosition location)
		{
			if (cacheGINetChg != null)
				for (int idx = 0; idx < cacheGINetChg.Length; idx++)
					if (cacheGINetChg[idx].Unit == unit && cacheGINetChg[idx].Location == location && cacheGINetChg[idx].EqualsInput(input))
						return cacheGINetChg[idx];
			return CacheIndicator<GINetChg>(new GINetChg(){ Unit = unit, Location = location }, input, ref cacheGINetChg);
		}

		public GIPbSAR GIPbSAR(ISeries<double> input, double acceleration, double accelerationMax, double accelerationStep)
		{
			if (cacheGIPbSAR != null)
				for (int idx = 0; idx < cacheGIPbSAR.Length; idx++)
					if (cacheGIPbSAR[idx].Acceleration == acceleration && cacheGIPbSAR[idx].AccelerationMax == accelerationMax && cacheGIPbSAR[idx].AccelerationStep == accelerationStep && cacheGIPbSAR[idx].EqualsInput(input))
						return cacheGIPbSAR[idx];
			return CacheIndicator<GIPbSAR>(new GIPbSAR(){ Acceleration = acceleration, AccelerationMax = accelerationMax, AccelerationStep = accelerationStep }, input, ref cacheGIPbSAR);
		}

		public GIPctSpd GIPctSpd(ISeries<double> input, int rocPeriod)
		{
			if (cacheGIPctSpd != null)
				for (int idx = 0; idx < cacheGIPctSpd.Length; idx++)
					if (cacheGIPctSpd[idx].RocPeriod == rocPeriod && cacheGIPctSpd[idx].EqualsInput(input))
						return cacheGIPctSpd[idx];
			return CacheIndicator<GIPctSpd>(new GIPctSpd(){ RocPeriod = rocPeriod }, input, ref cacheGIPctSpd);
		}

		public GIPriorMonthOHLC GIPriorMonthOHLC(ISeries<double> input)
		{
			if (cacheGIPriorMonthOHLC != null)
				for (int idx = 0; idx < cacheGIPriorMonthOHLC.Length; idx++)
					if ( cacheGIPriorMonthOHLC[idx].EqualsInput(input))
						return cacheGIPriorMonthOHLC[idx];
			return CacheIndicator<GIPriorMonthOHLC>(new GIPriorMonthOHLC(), input, ref cacheGIPriorMonthOHLC);
		}

		public GIPriorWeekOHLC GIPriorWeekOHLC(ISeries<double> input)
		{
			if (cacheGIPriorWeekOHLC != null)
				for (int idx = 0; idx < cacheGIPriorWeekOHLC.Length; idx++)
					if ( cacheGIPriorWeekOHLC[idx].EqualsInput(input))
						return cacheGIPriorWeekOHLC[idx];
			return CacheIndicator<GIPriorWeekOHLC>(new GIPriorWeekOHLC(), input, ref cacheGIPriorWeekOHLC);
		}

		public GISMI GISMI(ISeries<double> input, int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod, int sMICrossLevel)
		{
			if (cacheGISMI != null)
				for (int idx = 0; idx < cacheGISMI.Length; idx++)
					if (cacheGISMI[idx].EMAPeriod1 == eMAPeriod1 && cacheGISMI[idx].EMAPeriod2 == eMAPeriod2 && cacheGISMI[idx].Range == range && cacheGISMI[idx].SMITMAPeriod == sMITMAPeriod && cacheGISMI[idx].SMICrossLevel == sMICrossLevel && cacheGISMI[idx].EqualsInput(input))
						return cacheGISMI[idx];
			return CacheIndicator<GISMI>(new GISMI(){ EMAPeriod1 = eMAPeriod1, EMAPeriod2 = eMAPeriod2, Range = range, SMITMAPeriod = sMITMAPeriod, SMICrossLevel = sMICrossLevel }, input, ref cacheGISMI);
		}

		public GISnR GISnR(ISeries<double> input, bool showOvernightHL, bool showOpenHL, bool showLastdayHL, bool showLastdayClose, bool showTodayOpen, int timeOpen, int timeClose)
		{
			if (cacheGISnR != null)
				for (int idx = 0; idx < cacheGISnR.Length; idx++)
					if (cacheGISnR[idx].ShowOvernightHL == showOvernightHL && cacheGISnR[idx].ShowOpenHL == showOpenHL && cacheGISnR[idx].ShowLastdayHL == showLastdayHL && cacheGISnR[idx].ShowLastdayClose == showLastdayClose && cacheGISnR[idx].ShowTodayOpen == showTodayOpen && cacheGISnR[idx].TimeOpen == timeOpen && cacheGISnR[idx].TimeClose == timeClose && cacheGISnR[idx].EqualsInput(input))
						return cacheGISnR[idx];
			return CacheIndicator<GISnR>(new GISnR(){ ShowOvernightHL = showOvernightHL, ShowOpenHL = showOpenHL, ShowLastdayHL = showLastdayHL, ShowLastdayClose = showLastdayClose, ShowTodayOpen = showTodayOpen, TimeOpen = timeOpen, TimeClose = timeClose }, input, ref cacheGISnR);
		}

		public GISnRPriorWM GISnRPriorWM(ISeries<double> input, bool showWkClose, bool showWkHigh, bool showWkLow, bool showWkOpen, bool showMoClose, bool showMoHigh, bool showMoLow, bool showMoOpen)
		{
			if (cacheGISnRPriorWM != null)
				for (int idx = 0; idx < cacheGISnRPriorWM.Length; idx++)
					if (cacheGISnRPriorWM[idx].ShowWkClose == showWkClose && cacheGISnRPriorWM[idx].ShowWkHigh == showWkHigh && cacheGISnRPriorWM[idx].ShowWkLow == showWkLow && cacheGISnRPriorWM[idx].ShowWkOpen == showWkOpen && cacheGISnRPriorWM[idx].ShowMoClose == showMoClose && cacheGISnRPriorWM[idx].ShowMoHigh == showMoHigh && cacheGISnRPriorWM[idx].ShowMoLow == showMoLow && cacheGISnRPriorWM[idx].ShowMoOpen == showMoOpen && cacheGISnRPriorWM[idx].EqualsInput(input))
						return cacheGISnRPriorWM[idx];
			return CacheIndicator<GISnRPriorWM>(new GISnRPriorWM(){ ShowWkClose = showWkClose, ShowWkHigh = showWkHigh, ShowWkLow = showWkLow, ShowWkOpen = showWkOpen, ShowMoClose = showMoClose, ShowMoHigh = showMoHigh, ShowMoLow = showMoLow, ShowMoOpen = showMoOpen }, input, ref cacheGISnRPriorWM);
		}

		public GIVOL GIVOL(ISeries<double> input, int volPeriod, int volWPRPeriod)
		{
			if (cacheGIVOL != null)
				for (int idx = 0; idx < cacheGIVOL.Length; idx++)
					if (cacheGIVOL[idx].VolPeriod == volPeriod && cacheGIVOL[idx].VolWPRPeriod == volWPRPeriod && cacheGIVOL[idx].EqualsInput(input))
						return cacheGIVOL[idx];
			return CacheIndicator<GIVOL>(new GIVOL(){ VolPeriod = volPeriod, VolWPRPeriod = volWPRPeriod }, input, ref cacheGIVOL);
		}

		public GIVWAP GIVWAP(ISeries<double> input)
		{
			if (cacheGIVWAP != null)
				for (int idx = 0; idx < cacheGIVWAP.Length; idx++)
					if ( cacheGIVWAP[idx].EqualsInput(input))
						return cacheGIVWAP[idx];
			return CacheIndicator<GIVWAP>(new GIVWAP(), input, ref cacheGIVWAP);
		}

		public SMI SMI(ISeries<double> input, int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			if (cacheSMI != null)
				for (int idx = 0; idx < cacheSMI.Length; idx++)
					if (cacheSMI[idx].EMAPeriod1 == eMAPeriod1 && cacheSMI[idx].EMAPeriod2 == eMAPeriod2 && cacheSMI[idx].Range == range && cacheSMI[idx].SMITMAPeriod == sMITMAPeriod && cacheSMI[idx].EqualsInput(input))
						return cacheSMI[idx];
			return CacheIndicator<SMI>(new SMI(){ EMAPeriod1 = eMAPeriod1, EMAPeriod2 = eMAPeriod2, Range = range, SMITMAPeriod = sMITMAPeriod }, input, ref cacheSMI);
		}

		public PriceActionSwing.PriceActionSwing PriceActionSwing(ISeries<double> input, SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool ignoreInsideBars, bool useBreakouts)
		{
			if (cachePriceActionSwing != null)
				for (int idx = 0; idx < cachePriceActionSwing.Length; idx++)
					if (cachePriceActionSwing[idx].SwingType == swingType && cachePriceActionSwing[idx].SwingSize == swingSize && cachePriceActionSwing[idx].DtbStrength == dtbStrength && cachePriceActionSwing[idx].UseCloseValues == useCloseValues && cachePriceActionSwing[idx].SwingLengthType == swingLengthType && cachePriceActionSwing[idx].SwingDurationType == swingDurationType && cachePriceActionSwing[idx].ShowSwingPrice == showSwingPrice && cachePriceActionSwing[idx].ShowSwingLabel == showSwingLabel && cachePriceActionSwing[idx].ShowSwingPercent == showSwingPercent && cachePriceActionSwing[idx].SwingTimeType == swingTimeType && cachePriceActionSwing[idx].SwingVolumeType == swingVolumeType && cachePriceActionSwing[idx].VisualizationType == visualizationType && cachePriceActionSwing[idx].TextFont == textFont && cachePriceActionSwing[idx].TextOffsetLength == textOffsetLength && cachePriceActionSwing[idx].TextOffsetVolume == textOffsetVolume && cachePriceActionSwing[idx].TextOffsetPrice == textOffsetPrice && cachePriceActionSwing[idx].TextOffsetLabel == textOffsetLabel && cachePriceActionSwing[idx].TextOffsetTime == textOffsetTime && cachePriceActionSwing[idx].TextOffsetPercent == textOffsetPercent && cachePriceActionSwing[idx].ZigZagStyle == zigZagStyle && cachePriceActionSwing[idx].ZigZagWidth == zigZagWidth && cachePriceActionSwing[idx].IgnoreInsideBars == ignoreInsideBars && cachePriceActionSwing[idx].UseBreakouts == useBreakouts && cachePriceActionSwing[idx].EqualsInput(input))
						return cachePriceActionSwing[idx];
			return CacheIndicator<PriceActionSwing.PriceActionSwing>(new PriceActionSwing.PriceActionSwing(){ SwingType = swingType, SwingSize = swingSize, DtbStrength = dtbStrength, UseCloseValues = useCloseValues, SwingLengthType = swingLengthType, SwingDurationType = swingDurationType, ShowSwingPrice = showSwingPrice, ShowSwingLabel = showSwingLabel, ShowSwingPercent = showSwingPercent, SwingTimeType = swingTimeType, SwingVolumeType = swingVolumeType, VisualizationType = visualizationType, TextFont = textFont, TextOffsetLength = textOffsetLength, TextOffsetVolume = textOffsetVolume, TextOffsetPrice = textOffsetPrice, TextOffsetLabel = textOffsetLabel, TextOffsetTime = textOffsetTime, TextOffsetPercent = textOffsetPercent, ZigZagStyle = zigZagStyle, ZigZagWidth = zigZagWidth, IgnoreInsideBars = ignoreInsideBars, UseBreakouts = useBreakouts }, input, ref cachePriceActionSwing);
		}

		public PriceActionSwing.PriceActionSwingOscillator PriceActionSwingOscillator(ISeries<double> input, SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, Show showOscillator, bool useOldTrend, bool ignoreInsideBars, bool useBreakouts)
		{
			if (cachePriceActionSwingOscillator != null)
				for (int idx = 0; idx < cachePriceActionSwingOscillator.Length; idx++)
					if (cachePriceActionSwingOscillator[idx].SwingType == swingType && cachePriceActionSwingOscillator[idx].SwingSize == swingSize && cachePriceActionSwingOscillator[idx].DtbStrength == dtbStrength && cachePriceActionSwingOscillator[idx].UseCloseValues == useCloseValues && cachePriceActionSwingOscillator[idx].ShowOscillator == showOscillator && cachePriceActionSwingOscillator[idx].UseOldTrend == useOldTrend && cachePriceActionSwingOscillator[idx].IgnoreInsideBars == ignoreInsideBars && cachePriceActionSwingOscillator[idx].UseBreakouts == useBreakouts && cachePriceActionSwingOscillator[idx].EqualsInput(input))
						return cachePriceActionSwingOscillator[idx];
			return CacheIndicator<PriceActionSwing.PriceActionSwingOscillator>(new PriceActionSwing.PriceActionSwingOscillator(){ SwingType = swingType, SwingSize = swingSize, DtbStrength = dtbStrength, UseCloseValues = useCloseValues, ShowOscillator = showOscillator, UseOldTrend = useOldTrend, IgnoreInsideBars = ignoreInsideBars, UseBreakouts = useBreakouts }, input, ref cachePriceActionSwingOscillator);
		}

		public PriceActionSwing.PriceActionSwingPro PriceActionSwingPro(ISeries<double> input, SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, AbcPatternMode abcPattern, DivergenceMode divergenceIndicatorMode, DivergenceDirection divergenceDirectionMode, int param1, int param2, int param3, bool showNakedSwings, bool addSwingExtension, bool addSwingRetracementFast, bool addSwingRetracementSlow, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool showSwingSwitch, int swingSwitchOffsetInTicks, DashStyleHelper abcLineStyle, DashStyleHelper abcLineStyleRatio, int abcLineWidth, int abcLineWidthRatio, NinjaTrader.Gui.Tools.SimpleFont abcTextFont, int abcTextOffsetLabel, double abcMaxRetracement, double abcMinRetracement, DashStyleHelper entryLineStyle, int entryLineWidth, double retracementEntryValue, bool showEntryArrows, bool showHistoricalEntryLine, int yTickOffset, bool showDivergenceRegular, bool showDivergenceHidden, DashStyleHelper divDnLineStyle, DashStyleHelper divUpLineStyle, int divDnLineWidth, int divUpLineWidth, bool showHistoricalNakedSwings, DashStyleHelper nakedSwingDashStyle, int nakedSwingLineWidth, bool ignoreInsideBars, bool useBreakouts, bool alertAbc, bool alertAbcEntry, Priority alertAbcPriority, Priority alertAbcEntryPriority, string alertAbcLongSoundFileName, string alertAbcLongEntrySoundFileName, string alertAbcShortSoundFileName, string alertAbcShortEntrySoundFileName, bool alertDoubleBottom, Priority alertDoubleBottomPriority, string alertDoubleBottomMessage, string alertDoubleBottomSoundFileName, int alertDoubleBottomRearmSeconds, bool alertDoubleTop, Priority alertDoubleTopPriority, string alertDoubleTopMessage, string alertDoubleTopSoundFileName, int alertDoubleTopRearmSeconds, bool alertHigherLow, Priority alertHigherLowPriority, string alertHigherLowMessage, string alertHigherLowSoundFileName, int alertHigherLowRearmSeconds, bool alertLowerHigh, Priority alertLowerHighPriority, string alertLowerHighMessage, string alertLowerHighSoundFileName, int alertLowerHighRearmSeconds, bool alertSwingChange, Priority alertSwingChangePriority, string alertSwingChangeMessage, string alertSwingChangeSoundFileName, int alertSwingChangeRearmSeconds, bool alertDivergenceRegularHigh, Priority alertDivergenceRegularHighPriority, string alertDivergenceRegularHighMessage, string alertDivergenceRegularHighSoundFileName, int alertDivergenceRegularHighRearmSeconds, bool alertDivergenceHiddenHigh, Priority alertDivergenceHiddenHighPriority, string alertDivergenceHiddenHighMessage, string alertDivergenceHiddenHighSoundFileName, int alertDivergenceHiddenHighRearmSeconds, bool alertDivergenceRegularLow, Priority alertDivergenceRegularLowPriority, string alertDivergenceRegularLowMessage, string alertDivergenceRegularLowSoundFileName, int alertDivergenceRegularLowRearmSeconds, bool alertDivergenceHiddenLow, Priority alertDivergenceHiddenLowPriority, string alertDivergenceHiddenLowMessage, string alertDivergenceHiddenLowSoundFileName, int alertDivergenceHiddenLowRearmSeconds)
		{
			if (cachePriceActionSwingPro != null)
				for (int idx = 0; idx < cachePriceActionSwingPro.Length; idx++)
					if (cachePriceActionSwingPro[idx].SwingType == swingType && cachePriceActionSwingPro[idx].SwingSize == swingSize && cachePriceActionSwingPro[idx].DtbStrength == dtbStrength && cachePriceActionSwingPro[idx].UseCloseValues == useCloseValues && cachePriceActionSwingPro[idx].AbcPattern == abcPattern && cachePriceActionSwingPro[idx].DivergenceIndicatorMode == divergenceIndicatorMode && cachePriceActionSwingPro[idx].DivergenceDirectionMode == divergenceDirectionMode && cachePriceActionSwingPro[idx].Param1 == param1 && cachePriceActionSwingPro[idx].Param2 == param2 && cachePriceActionSwingPro[idx].Param3 == param3 && cachePriceActionSwingPro[idx].ShowNakedSwings == showNakedSwings && cachePriceActionSwingPro[idx].AddSwingExtension == addSwingExtension && cachePriceActionSwingPro[idx].AddSwingRetracementFast == addSwingRetracementFast && cachePriceActionSwingPro[idx].AddSwingRetracementSlow == addSwingRetracementSlow && cachePriceActionSwingPro[idx].SwingLengthType == swingLengthType && cachePriceActionSwingPro[idx].SwingDurationType == swingDurationType && cachePriceActionSwingPro[idx].ShowSwingPrice == showSwingPrice && cachePriceActionSwingPro[idx].ShowSwingLabel == showSwingLabel && cachePriceActionSwingPro[idx].ShowSwingPercent == showSwingPercent && cachePriceActionSwingPro[idx].SwingTimeType == swingTimeType && cachePriceActionSwingPro[idx].SwingVolumeType == swingVolumeType && cachePriceActionSwingPro[idx].VisualizationType == visualizationType && cachePriceActionSwingPro[idx].TextFont == textFont && cachePriceActionSwingPro[idx].TextOffsetLength == textOffsetLength && cachePriceActionSwingPro[idx].TextOffsetVolume == textOffsetVolume && cachePriceActionSwingPro[idx].TextOffsetPrice == textOffsetPrice && cachePriceActionSwingPro[idx].TextOffsetLabel == textOffsetLabel && cachePriceActionSwingPro[idx].TextOffsetTime == textOffsetTime && cachePriceActionSwingPro[idx].TextOffsetPercent == textOffsetPercent && cachePriceActionSwingPro[idx].ZigZagStyle == zigZagStyle && cachePriceActionSwingPro[idx].ZigZagWidth == zigZagWidth && cachePriceActionSwingPro[idx].ShowSwingSwitch == showSwingSwitch && cachePriceActionSwingPro[idx].SwingSwitchOffsetInTicks == swingSwitchOffsetInTicks && cachePriceActionSwingPro[idx].AbcLineStyle == abcLineStyle && cachePriceActionSwingPro[idx].AbcLineStyleRatio == abcLineStyleRatio && cachePriceActionSwingPro[idx].AbcLineWidth == abcLineWidth && cachePriceActionSwingPro[idx].AbcLineWidthRatio == abcLineWidthRatio && cachePriceActionSwingPro[idx].AbcTextFont == abcTextFont && cachePriceActionSwingPro[idx].AbcTextOffsetLabel == abcTextOffsetLabel && cachePriceActionSwingPro[idx].AbcMaxRetracement == abcMaxRetracement && cachePriceActionSwingPro[idx].AbcMinRetracement == abcMinRetracement && cachePriceActionSwingPro[idx].EntryLineStyle == entryLineStyle && cachePriceActionSwingPro[idx].EntryLineWidth == entryLineWidth && cachePriceActionSwingPro[idx].RetracementEntryValue == retracementEntryValue && cachePriceActionSwingPro[idx].ShowEntryArrows == showEntryArrows && cachePriceActionSwingPro[idx].ShowHistoricalEntryLine == showHistoricalEntryLine && cachePriceActionSwingPro[idx].YTickOffset == yTickOffset && cachePriceActionSwingPro[idx].ShowDivergenceRegular == showDivergenceRegular && cachePriceActionSwingPro[idx].ShowDivergenceHidden == showDivergenceHidden && cachePriceActionSwingPro[idx].DivDnLineStyle == divDnLineStyle && cachePriceActionSwingPro[idx].DivUpLineStyle == divUpLineStyle && cachePriceActionSwingPro[idx].DivDnLineWidth == divDnLineWidth && cachePriceActionSwingPro[idx].DivUpLineWidth == divUpLineWidth && cachePriceActionSwingPro[idx].ShowHistoricalNakedSwings == showHistoricalNakedSwings && cachePriceActionSwingPro[idx].NakedSwingDashStyle == nakedSwingDashStyle && cachePriceActionSwingPro[idx].NakedSwingLineWidth == nakedSwingLineWidth && cachePriceActionSwingPro[idx].IgnoreInsideBars == ignoreInsideBars && cachePriceActionSwingPro[idx].UseBreakouts == useBreakouts && cachePriceActionSwingPro[idx].AlertAbc == alertAbc && cachePriceActionSwingPro[idx].AlertAbcEntry == alertAbcEntry && cachePriceActionSwingPro[idx].AlertAbcPriority == alertAbcPriority && cachePriceActionSwingPro[idx].AlertAbcEntryPriority == alertAbcEntryPriority && cachePriceActionSwingPro[idx].AlertAbcLongSoundFileName == alertAbcLongSoundFileName && cachePriceActionSwingPro[idx].AlertAbcLongEntrySoundFileName == alertAbcLongEntrySoundFileName && cachePriceActionSwingPro[idx].AlertAbcShortSoundFileName == alertAbcShortSoundFileName && cachePriceActionSwingPro[idx].AlertAbcShortEntrySoundFileName == alertAbcShortEntrySoundFileName && cachePriceActionSwingPro[idx].AlertDoubleBottom == alertDoubleBottom && cachePriceActionSwingPro[idx].AlertDoubleBottomPriority == alertDoubleBottomPriority && cachePriceActionSwingPro[idx].AlertDoubleBottomMessage == alertDoubleBottomMessage && cachePriceActionSwingPro[idx].AlertDoubleBottomSoundFileName == alertDoubleBottomSoundFileName && cachePriceActionSwingPro[idx].AlertDoubleBottomRearmSeconds == alertDoubleBottomRearmSeconds && cachePriceActionSwingPro[idx].AlertDoubleTop == alertDoubleTop && cachePriceActionSwingPro[idx].AlertDoubleTopPriority == alertDoubleTopPriority && cachePriceActionSwingPro[idx].AlertDoubleTopMessage == alertDoubleTopMessage && cachePriceActionSwingPro[idx].AlertDoubleTopSoundFileName == alertDoubleTopSoundFileName && cachePriceActionSwingPro[idx].AlertDoubleTopRearmSeconds == alertDoubleTopRearmSeconds && cachePriceActionSwingPro[idx].AlertHigherLow == alertHigherLow && cachePriceActionSwingPro[idx].AlertHigherLowPriority == alertHigherLowPriority && cachePriceActionSwingPro[idx].AlertHigherLowMessage == alertHigherLowMessage && cachePriceActionSwingPro[idx].AlertHigherLowSoundFileName == alertHigherLowSoundFileName && cachePriceActionSwingPro[idx].AlertHigherLowRearmSeconds == alertHigherLowRearmSeconds && cachePriceActionSwingPro[idx].AlertLowerHigh == alertLowerHigh && cachePriceActionSwingPro[idx].AlertLowerHighPriority == alertLowerHighPriority && cachePriceActionSwingPro[idx].AlertLowerHighMessage == alertLowerHighMessage && cachePriceActionSwingPro[idx].AlertLowerHighSoundFileName == alertLowerHighSoundFileName && cachePriceActionSwingPro[idx].AlertLowerHighRearmSeconds == alertLowerHighRearmSeconds && cachePriceActionSwingPro[idx].AlertSwingChange == alertSwingChange && cachePriceActionSwingPro[idx].AlertSwingChangePriority == alertSwingChangePriority && cachePriceActionSwingPro[idx].AlertSwingChangeMessage == alertSwingChangeMessage && cachePriceActionSwingPro[idx].AlertSwingChangeSoundFileName == alertSwingChangeSoundFileName && cachePriceActionSwingPro[idx].AlertSwingChangeRearmSeconds == alertSwingChangeRearmSeconds && cachePriceActionSwingPro[idx].AlertDivergenceRegularHigh == alertDivergenceRegularHigh && cachePriceActionSwingPro[idx].AlertDivergenceRegularHighPriority == alertDivergenceRegularHighPriority && cachePriceActionSwingPro[idx].AlertDivergenceRegularHighMessage == alertDivergenceRegularHighMessage && cachePriceActionSwingPro[idx].AlertDivergenceRegularHighSoundFileName == alertDivergenceRegularHighSoundFileName && cachePriceActionSwingPro[idx].AlertDivergenceRegularHighRearmSeconds == alertDivergenceRegularHighRearmSeconds && cachePriceActionSwingPro[idx].AlertDivergenceHiddenHigh == alertDivergenceHiddenHigh && cachePriceActionSwingPro[idx].AlertDivergenceHiddenHighPriority == alertDivergenceHiddenHighPriority && cachePriceActionSwingPro[idx].AlertDivergenceHiddenHighMessage == alertDivergenceHiddenHighMessage && cachePriceActionSwingPro[idx].AlertDivergenceHiddenHighSoundFileName == alertDivergenceHiddenHighSoundFileName && cachePriceActionSwingPro[idx].AlertDivergenceHiddenHighRearmSeconds == alertDivergenceHiddenHighRearmSeconds && cachePriceActionSwingPro[idx].AlertDivergenceRegularLow == alertDivergenceRegularLow && cachePriceActionSwingPro[idx].AlertDivergenceRegularLowPriority == alertDivergenceRegularLowPriority && cachePriceActionSwingPro[idx].AlertDivergenceRegularLowMessage == alertDivergenceRegularLowMessage && cachePriceActionSwingPro[idx].AlertDivergenceRegularLowSoundFileName == alertDivergenceRegularLowSoundFileName && cachePriceActionSwingPro[idx].AlertDivergenceRegularLowRearmSeconds == alertDivergenceRegularLowRearmSeconds && cachePriceActionSwingPro[idx].AlertDivergenceHiddenLow == alertDivergenceHiddenLow && cachePriceActionSwingPro[idx].AlertDivergenceHiddenLowPriority == alertDivergenceHiddenLowPriority && cachePriceActionSwingPro[idx].AlertDivergenceHiddenLowMessage == alertDivergenceHiddenLowMessage && cachePriceActionSwingPro[idx].AlertDivergenceHiddenLowSoundFileName == alertDivergenceHiddenLowSoundFileName && cachePriceActionSwingPro[idx].AlertDivergenceHiddenLowRearmSeconds == alertDivergenceHiddenLowRearmSeconds && cachePriceActionSwingPro[idx].EqualsInput(input))
						return cachePriceActionSwingPro[idx];
			return CacheIndicator<PriceActionSwing.PriceActionSwingPro>(new PriceActionSwing.PriceActionSwingPro(){ SwingType = swingType, SwingSize = swingSize, DtbStrength = dtbStrength, UseCloseValues = useCloseValues, AbcPattern = abcPattern, DivergenceIndicatorMode = divergenceIndicatorMode, DivergenceDirectionMode = divergenceDirectionMode, Param1 = param1, Param2 = param2, Param3 = param3, ShowNakedSwings = showNakedSwings, AddSwingExtension = addSwingExtension, AddSwingRetracementFast = addSwingRetracementFast, AddSwingRetracementSlow = addSwingRetracementSlow, SwingLengthType = swingLengthType, SwingDurationType = swingDurationType, ShowSwingPrice = showSwingPrice, ShowSwingLabel = showSwingLabel, ShowSwingPercent = showSwingPercent, SwingTimeType = swingTimeType, SwingVolumeType = swingVolumeType, VisualizationType = visualizationType, TextFont = textFont, TextOffsetLength = textOffsetLength, TextOffsetVolume = textOffsetVolume, TextOffsetPrice = textOffsetPrice, TextOffsetLabel = textOffsetLabel, TextOffsetTime = textOffsetTime, TextOffsetPercent = textOffsetPercent, ZigZagStyle = zigZagStyle, ZigZagWidth = zigZagWidth, ShowSwingSwitch = showSwingSwitch, SwingSwitchOffsetInTicks = swingSwitchOffsetInTicks, AbcLineStyle = abcLineStyle, AbcLineStyleRatio = abcLineStyleRatio, AbcLineWidth = abcLineWidth, AbcLineWidthRatio = abcLineWidthRatio, AbcTextFont = abcTextFont, AbcTextOffsetLabel = abcTextOffsetLabel, AbcMaxRetracement = abcMaxRetracement, AbcMinRetracement = abcMinRetracement, EntryLineStyle = entryLineStyle, EntryLineWidth = entryLineWidth, RetracementEntryValue = retracementEntryValue, ShowEntryArrows = showEntryArrows, ShowHistoricalEntryLine = showHistoricalEntryLine, YTickOffset = yTickOffset, ShowDivergenceRegular = showDivergenceRegular, ShowDivergenceHidden = showDivergenceHidden, DivDnLineStyle = divDnLineStyle, DivUpLineStyle = divUpLineStyle, DivDnLineWidth = divDnLineWidth, DivUpLineWidth = divUpLineWidth, ShowHistoricalNakedSwings = showHistoricalNakedSwings, NakedSwingDashStyle = nakedSwingDashStyle, NakedSwingLineWidth = nakedSwingLineWidth, IgnoreInsideBars = ignoreInsideBars, UseBreakouts = useBreakouts, AlertAbc = alertAbc, AlertAbcEntry = alertAbcEntry, AlertAbcPriority = alertAbcPriority, AlertAbcEntryPriority = alertAbcEntryPriority, AlertAbcLongSoundFileName = alertAbcLongSoundFileName, AlertAbcLongEntrySoundFileName = alertAbcLongEntrySoundFileName, AlertAbcShortSoundFileName = alertAbcShortSoundFileName, AlertAbcShortEntrySoundFileName = alertAbcShortEntrySoundFileName, AlertDoubleBottom = alertDoubleBottom, AlertDoubleBottomPriority = alertDoubleBottomPriority, AlertDoubleBottomMessage = alertDoubleBottomMessage, AlertDoubleBottomSoundFileName = alertDoubleBottomSoundFileName, AlertDoubleBottomRearmSeconds = alertDoubleBottomRearmSeconds, AlertDoubleTop = alertDoubleTop, AlertDoubleTopPriority = alertDoubleTopPriority, AlertDoubleTopMessage = alertDoubleTopMessage, AlertDoubleTopSoundFileName = alertDoubleTopSoundFileName, AlertDoubleTopRearmSeconds = alertDoubleTopRearmSeconds, AlertHigherLow = alertHigherLow, AlertHigherLowPriority = alertHigherLowPriority, AlertHigherLowMessage = alertHigherLowMessage, AlertHigherLowSoundFileName = alertHigherLowSoundFileName, AlertHigherLowRearmSeconds = alertHigherLowRearmSeconds, AlertLowerHigh = alertLowerHigh, AlertLowerHighPriority = alertLowerHighPriority, AlertLowerHighMessage = alertLowerHighMessage, AlertLowerHighSoundFileName = alertLowerHighSoundFileName, AlertLowerHighRearmSeconds = alertLowerHighRearmSeconds, AlertSwingChange = alertSwingChange, AlertSwingChangePriority = alertSwingChangePriority, AlertSwingChangeMessage = alertSwingChangeMessage, AlertSwingChangeSoundFileName = alertSwingChangeSoundFileName, AlertSwingChangeRearmSeconds = alertSwingChangeRearmSeconds, AlertDivergenceRegularHigh = alertDivergenceRegularHigh, AlertDivergenceRegularHighPriority = alertDivergenceRegularHighPriority, AlertDivergenceRegularHighMessage = alertDivergenceRegularHighMessage, AlertDivergenceRegularHighSoundFileName = alertDivergenceRegularHighSoundFileName, AlertDivergenceRegularHighRearmSeconds = alertDivergenceRegularHighRearmSeconds, AlertDivergenceHiddenHigh = alertDivergenceHiddenHigh, AlertDivergenceHiddenHighPriority = alertDivergenceHiddenHighPriority, AlertDivergenceHiddenHighMessage = alertDivergenceHiddenHighMessage, AlertDivergenceHiddenHighSoundFileName = alertDivergenceHiddenHighSoundFileName, AlertDivergenceHiddenHighRearmSeconds = alertDivergenceHiddenHighRearmSeconds, AlertDivergenceRegularLow = alertDivergenceRegularLow, AlertDivergenceRegularLowPriority = alertDivergenceRegularLowPriority, AlertDivergenceRegularLowMessage = alertDivergenceRegularLowMessage, AlertDivergenceRegularLowSoundFileName = alertDivergenceRegularLowSoundFileName, AlertDivergenceRegularLowRearmSeconds = alertDivergenceRegularLowRearmSeconds, AlertDivergenceHiddenLow = alertDivergenceHiddenLow, AlertDivergenceHiddenLowPriority = alertDivergenceHiddenLowPriority, AlertDivergenceHiddenLowMessage = alertDivergenceHiddenLowMessage, AlertDivergenceHiddenLowSoundFileName = alertDivergenceHiddenLowSoundFileName, AlertDivergenceHiddenLowRearmSeconds = alertDivergenceHiddenLowRearmSeconds }, input, ref cachePriceActionSwingPro);
		}

		public ZTraderInd.GIndicatorProxy GIndicatorProxy(ISeries<double> input, GStrategyBase gSZTrader)
		{
			if (cacheGIndicatorProxy != null)
				for (int idx = 0; idx < cacheGIndicatorProxy.Length; idx++)
					if (cacheGIndicatorProxy[idx].GSZTrader == gSZTrader && cacheGIndicatorProxy[idx].EqualsInput(input))
						return cacheGIndicatorProxy[idx];
			return CacheIndicator<ZTraderInd.GIndicatorProxy>(new ZTraderInd.GIndicatorProxy(){ GSZTrader = gSZTrader }, input, ref cacheGIndicatorProxy);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.GIAwesomeOscillator GIAwesomeOscillator(int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType, bool showLines)
		{
			return indicator.GIAwesomeOscillator(Input, fastPeriod, slowPeriod, smooth, movingAverageType, showLines);
		}

		public Indicators.GIEMA GIEMA(int period, int offsetTicks)
		{
			return indicator.GIEMA(Input, period, offsetTicks);
		}

		public Indicators.GIFibonacci GIFibonacci(int param1)
		{
			return indicator.GIFibonacci(Input, param1);
		}

		public Indicators.GIGetHighLowByPeriod GIGetHighLowByPeriod(SignalBarByType periodStartBy, SignalBarByType periodEndBy, int startHour, int startMinute, int endHour, int endMinute)
		{
			return indicator.GIGetHighLowByPeriod(Input, periodStartBy, periodEndBy, startHour, startMinute, endHour, endMinute);
		}

		public Indicators.GIGetHighLowByTimeRange GIGetHighLowByTimeRange(int startHour, int startMinute, int endHour, int endMinute)
		{
			return indicator.GIGetHighLowByTimeRange(Input, startHour, startMinute, endHour, endMinute);
		}

		public Indicators.GIHLnBars GIHLnBars(int period)
		{
			return indicator.GIHLnBars(Input, period);
		}

		public Indicators.GIKAMA GIKAMA(int fast, int period, int slow)
		{
			return indicator.GIKAMA(Input, fast, period, slow);
		}

		public Indicators.GIKeyReversal GIKeyReversal(int periodLeft, int periodRight)
		{
			return indicator.GIKeyReversal(Input, periodLeft, periodRight);
		}

		public Indicators.GIMktCtx GIMktCtx(int ctxFilePath)
		{
			return indicator.GIMktCtx(Input, ctxFilePath);
		}

		public Indicators.GINBarsUpDn GINBarsUpDn(int barCount, bool barUp, bool higherHigh, bool higherLow, bool barDown, bool lowerHigh, bool lowerLow)
		{
			return indicator.GINBarsUpDn(Input, barCount, barUp, higherHigh, higherLow, barDown, lowerHigh, lowerLow);
		}

		public Indicators.GINetChg GINetChg(Cbi.PerformanceUnit unit, NetChgPosition location)
		{
			return indicator.GINetChg(Input, unit, location);
		}

		public Indicators.GIPbSAR GIPbSAR(double acceleration, double accelerationMax, double accelerationStep)
		{
			return indicator.GIPbSAR(Input, acceleration, accelerationMax, accelerationStep);
		}

		public Indicators.GIPctSpd GIPctSpd(int rocPeriod)
		{
			return indicator.GIPctSpd(Input, rocPeriod);
		}

		public Indicators.GIPriorMonthOHLC GIPriorMonthOHLC()
		{
			return indicator.GIPriorMonthOHLC(Input);
		}

		public Indicators.GIPriorWeekOHLC GIPriorWeekOHLC()
		{
			return indicator.GIPriorWeekOHLC(Input);
		}

		public Indicators.GISMI GISMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod, int sMICrossLevel)
		{
			return indicator.GISMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod, sMICrossLevel);
		}

		public Indicators.GISnR GISnR(bool showOvernightHL, bool showOpenHL, bool showLastdayHL, bool showLastdayClose, bool showTodayOpen, int timeOpen, int timeClose)
		{
			return indicator.GISnR(Input, showOvernightHL, showOpenHL, showLastdayHL, showLastdayClose, showTodayOpen, timeOpen, timeClose);
		}

		public Indicators.GISnRPriorWM GISnRPriorWM(bool showWkClose, bool showWkHigh, bool showWkLow, bool showWkOpen, bool showMoClose, bool showMoHigh, bool showMoLow, bool showMoOpen)
		{
			return indicator.GISnRPriorWM(Input, showWkClose, showWkHigh, showWkLow, showWkOpen, showMoClose, showMoHigh, showMoLow, showMoOpen);
		}

		public Indicators.GIVOL GIVOL(int volPeriod, int volWPRPeriod)
		{
			return indicator.GIVOL(Input, volPeriod, volWPRPeriod);
		}

		public Indicators.GIVWAP GIVWAP()
		{
			return indicator.GIVWAP(Input);
		}

		public Indicators.SMI SMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.SMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

		public Indicators.PriceActionSwing.PriceActionSwing PriceActionSwing(SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool ignoreInsideBars, bool useBreakouts)
		{
			return indicator.PriceActionSwing(Input, swingType, swingSize, dtbStrength, useCloseValues, swingLengthType, swingDurationType, showSwingPrice, showSwingLabel, showSwingPercent, swingTimeType, swingVolumeType, visualizationType, textFont, textOffsetLength, textOffsetVolume, textOffsetPrice, textOffsetLabel, textOffsetTime, textOffsetPercent, zigZagStyle, zigZagWidth, ignoreInsideBars, useBreakouts);
		}

		public Indicators.PriceActionSwing.PriceActionSwingOscillator PriceActionSwingOscillator(SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, Show showOscillator, bool useOldTrend, bool ignoreInsideBars, bool useBreakouts)
		{
			return indicator.PriceActionSwingOscillator(Input, swingType, swingSize, dtbStrength, useCloseValues, showOscillator, useOldTrend, ignoreInsideBars, useBreakouts);
		}

		public Indicators.PriceActionSwing.PriceActionSwingPro PriceActionSwingPro(SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, AbcPatternMode abcPattern, DivergenceMode divergenceIndicatorMode, DivergenceDirection divergenceDirectionMode, int param1, int param2, int param3, bool showNakedSwings, bool addSwingExtension, bool addSwingRetracementFast, bool addSwingRetracementSlow, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool showSwingSwitch, int swingSwitchOffsetInTicks, DashStyleHelper abcLineStyle, DashStyleHelper abcLineStyleRatio, int abcLineWidth, int abcLineWidthRatio, NinjaTrader.Gui.Tools.SimpleFont abcTextFont, int abcTextOffsetLabel, double abcMaxRetracement, double abcMinRetracement, DashStyleHelper entryLineStyle, int entryLineWidth, double retracementEntryValue, bool showEntryArrows, bool showHistoricalEntryLine, int yTickOffset, bool showDivergenceRegular, bool showDivergenceHidden, DashStyleHelper divDnLineStyle, DashStyleHelper divUpLineStyle, int divDnLineWidth, int divUpLineWidth, bool showHistoricalNakedSwings, DashStyleHelper nakedSwingDashStyle, int nakedSwingLineWidth, bool ignoreInsideBars, bool useBreakouts, bool alertAbc, bool alertAbcEntry, Priority alertAbcPriority, Priority alertAbcEntryPriority, string alertAbcLongSoundFileName, string alertAbcLongEntrySoundFileName, string alertAbcShortSoundFileName, string alertAbcShortEntrySoundFileName, bool alertDoubleBottom, Priority alertDoubleBottomPriority, string alertDoubleBottomMessage, string alertDoubleBottomSoundFileName, int alertDoubleBottomRearmSeconds, bool alertDoubleTop, Priority alertDoubleTopPriority, string alertDoubleTopMessage, string alertDoubleTopSoundFileName, int alertDoubleTopRearmSeconds, bool alertHigherLow, Priority alertHigherLowPriority, string alertHigherLowMessage, string alertHigherLowSoundFileName, int alertHigherLowRearmSeconds, bool alertLowerHigh, Priority alertLowerHighPriority, string alertLowerHighMessage, string alertLowerHighSoundFileName, int alertLowerHighRearmSeconds, bool alertSwingChange, Priority alertSwingChangePriority, string alertSwingChangeMessage, string alertSwingChangeSoundFileName, int alertSwingChangeRearmSeconds, bool alertDivergenceRegularHigh, Priority alertDivergenceRegularHighPriority, string alertDivergenceRegularHighMessage, string alertDivergenceRegularHighSoundFileName, int alertDivergenceRegularHighRearmSeconds, bool alertDivergenceHiddenHigh, Priority alertDivergenceHiddenHighPriority, string alertDivergenceHiddenHighMessage, string alertDivergenceHiddenHighSoundFileName, int alertDivergenceHiddenHighRearmSeconds, bool alertDivergenceRegularLow, Priority alertDivergenceRegularLowPriority, string alertDivergenceRegularLowMessage, string alertDivergenceRegularLowSoundFileName, int alertDivergenceRegularLowRearmSeconds, bool alertDivergenceHiddenLow, Priority alertDivergenceHiddenLowPriority, string alertDivergenceHiddenLowMessage, string alertDivergenceHiddenLowSoundFileName, int alertDivergenceHiddenLowRearmSeconds)
		{
			return indicator.PriceActionSwingPro(Input, swingType, swingSize, dtbStrength, useCloseValues, abcPattern, divergenceIndicatorMode, divergenceDirectionMode, param1, param2, param3, showNakedSwings, addSwingExtension, addSwingRetracementFast, addSwingRetracementSlow, swingLengthType, swingDurationType, showSwingPrice, showSwingLabel, showSwingPercent, swingTimeType, swingVolumeType, visualizationType, textFont, textOffsetLength, textOffsetVolume, textOffsetPrice, textOffsetLabel, textOffsetTime, textOffsetPercent, zigZagStyle, zigZagWidth, showSwingSwitch, swingSwitchOffsetInTicks, abcLineStyle, abcLineStyleRatio, abcLineWidth, abcLineWidthRatio, abcTextFont, abcTextOffsetLabel, abcMaxRetracement, abcMinRetracement, entryLineStyle, entryLineWidth, retracementEntryValue, showEntryArrows, showHistoricalEntryLine, yTickOffset, showDivergenceRegular, showDivergenceHidden, divDnLineStyle, divUpLineStyle, divDnLineWidth, divUpLineWidth, showHistoricalNakedSwings, nakedSwingDashStyle, nakedSwingLineWidth, ignoreInsideBars, useBreakouts, alertAbc, alertAbcEntry, alertAbcPriority, alertAbcEntryPriority, alertAbcLongSoundFileName, alertAbcLongEntrySoundFileName, alertAbcShortSoundFileName, alertAbcShortEntrySoundFileName, alertDoubleBottom, alertDoubleBottomPriority, alertDoubleBottomMessage, alertDoubleBottomSoundFileName, alertDoubleBottomRearmSeconds, alertDoubleTop, alertDoubleTopPriority, alertDoubleTopMessage, alertDoubleTopSoundFileName, alertDoubleTopRearmSeconds, alertHigherLow, alertHigherLowPriority, alertHigherLowMessage, alertHigherLowSoundFileName, alertHigherLowRearmSeconds, alertLowerHigh, alertLowerHighPriority, alertLowerHighMessage, alertLowerHighSoundFileName, alertLowerHighRearmSeconds, alertSwingChange, alertSwingChangePriority, alertSwingChangeMessage, alertSwingChangeSoundFileName, alertSwingChangeRearmSeconds, alertDivergenceRegularHigh, alertDivergenceRegularHighPriority, alertDivergenceRegularHighMessage, alertDivergenceRegularHighSoundFileName, alertDivergenceRegularHighRearmSeconds, alertDivergenceHiddenHigh, alertDivergenceHiddenHighPriority, alertDivergenceHiddenHighMessage, alertDivergenceHiddenHighSoundFileName, alertDivergenceHiddenHighRearmSeconds, alertDivergenceRegularLow, alertDivergenceRegularLowPriority, alertDivergenceRegularLowMessage, alertDivergenceRegularLowSoundFileName, alertDivergenceRegularLowRearmSeconds, alertDivergenceHiddenLow, alertDivergenceHiddenLowPriority, alertDivergenceHiddenLowMessage, alertDivergenceHiddenLowSoundFileName, alertDivergenceHiddenLowRearmSeconds);
		}

		public Indicators.ZTraderInd.GIndicatorProxy GIndicatorProxy(GStrategyBase gSZTrader)
		{
			return indicator.GIndicatorProxy(Input, gSZTrader);
		}


		
		public Indicators.GIAwesomeOscillator GIAwesomeOscillator(ISeries<double> input , int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType, bool showLines)
		{
			return indicator.GIAwesomeOscillator(input, fastPeriod, slowPeriod, smooth, movingAverageType, showLines);
		}

		public Indicators.GIEMA GIEMA(ISeries<double> input , int period, int offsetTicks)
		{
			return indicator.GIEMA(input, period, offsetTicks);
		}

		public Indicators.GIFibonacci GIFibonacci(ISeries<double> input , int param1)
		{
			return indicator.GIFibonacci(input, param1);
		}

		public Indicators.GIGetHighLowByPeriod GIGetHighLowByPeriod(ISeries<double> input , SignalBarByType periodStartBy, SignalBarByType periodEndBy, int startHour, int startMinute, int endHour, int endMinute)
		{
			return indicator.GIGetHighLowByPeriod(input, periodStartBy, periodEndBy, startHour, startMinute, endHour, endMinute);
		}

		public Indicators.GIGetHighLowByTimeRange GIGetHighLowByTimeRange(ISeries<double> input , int startHour, int startMinute, int endHour, int endMinute)
		{
			return indicator.GIGetHighLowByTimeRange(input, startHour, startMinute, endHour, endMinute);
		}

		public Indicators.GIHLnBars GIHLnBars(ISeries<double> input , int period)
		{
			return indicator.GIHLnBars(input, period);
		}

		public Indicators.GIKAMA GIKAMA(ISeries<double> input , int fast, int period, int slow)
		{
			return indicator.GIKAMA(input, fast, period, slow);
		}

		public Indicators.GIKeyReversal GIKeyReversal(ISeries<double> input , int periodLeft, int periodRight)
		{
			return indicator.GIKeyReversal(input, periodLeft, periodRight);
		}

		public Indicators.GIMktCtx GIMktCtx(ISeries<double> input , int ctxFilePath)
		{
			return indicator.GIMktCtx(input, ctxFilePath);
		}

		public Indicators.GINBarsUpDn GINBarsUpDn(ISeries<double> input , int barCount, bool barUp, bool higherHigh, bool higherLow, bool barDown, bool lowerHigh, bool lowerLow)
		{
			return indicator.GINBarsUpDn(input, barCount, barUp, higherHigh, higherLow, barDown, lowerHigh, lowerLow);
		}

		public Indicators.GINetChg GINetChg(ISeries<double> input , Cbi.PerformanceUnit unit, NetChgPosition location)
		{
			return indicator.GINetChg(input, unit, location);
		}

		public Indicators.GIPbSAR GIPbSAR(ISeries<double> input , double acceleration, double accelerationMax, double accelerationStep)
		{
			return indicator.GIPbSAR(input, acceleration, accelerationMax, accelerationStep);
		}

		public Indicators.GIPctSpd GIPctSpd(ISeries<double> input , int rocPeriod)
		{
			return indicator.GIPctSpd(input, rocPeriod);
		}

		public Indicators.GIPriorMonthOHLC GIPriorMonthOHLC(ISeries<double> input )
		{
			return indicator.GIPriorMonthOHLC(input);
		}

		public Indicators.GIPriorWeekOHLC GIPriorWeekOHLC(ISeries<double> input )
		{
			return indicator.GIPriorWeekOHLC(input);
		}

		public Indicators.GISMI GISMI(ISeries<double> input , int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod, int sMICrossLevel)
		{
			return indicator.GISMI(input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod, sMICrossLevel);
		}

		public Indicators.GISnR GISnR(ISeries<double> input , bool showOvernightHL, bool showOpenHL, bool showLastdayHL, bool showLastdayClose, bool showTodayOpen, int timeOpen, int timeClose)
		{
			return indicator.GISnR(input, showOvernightHL, showOpenHL, showLastdayHL, showLastdayClose, showTodayOpen, timeOpen, timeClose);
		}

		public Indicators.GISnRPriorWM GISnRPriorWM(ISeries<double> input , bool showWkClose, bool showWkHigh, bool showWkLow, bool showWkOpen, bool showMoClose, bool showMoHigh, bool showMoLow, bool showMoOpen)
		{
			return indicator.GISnRPriorWM(input, showWkClose, showWkHigh, showWkLow, showWkOpen, showMoClose, showMoHigh, showMoLow, showMoOpen);
		}

		public Indicators.GIVOL GIVOL(ISeries<double> input , int volPeriod, int volWPRPeriod)
		{
			return indicator.GIVOL(input, volPeriod, volWPRPeriod);
		}

		public Indicators.GIVWAP GIVWAP(ISeries<double> input )
		{
			return indicator.GIVWAP(input);
		}

		public Indicators.SMI SMI(ISeries<double> input , int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.SMI(input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

		public Indicators.PriceActionSwing.PriceActionSwing PriceActionSwing(ISeries<double> input , SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool ignoreInsideBars, bool useBreakouts)
		{
			return indicator.PriceActionSwing(input, swingType, swingSize, dtbStrength, useCloseValues, swingLengthType, swingDurationType, showSwingPrice, showSwingLabel, showSwingPercent, swingTimeType, swingVolumeType, visualizationType, textFont, textOffsetLength, textOffsetVolume, textOffsetPrice, textOffsetLabel, textOffsetTime, textOffsetPercent, zigZagStyle, zigZagWidth, ignoreInsideBars, useBreakouts);
		}

		public Indicators.PriceActionSwing.PriceActionSwingOscillator PriceActionSwingOscillator(ISeries<double> input , SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, Show showOscillator, bool useOldTrend, bool ignoreInsideBars, bool useBreakouts)
		{
			return indicator.PriceActionSwingOscillator(input, swingType, swingSize, dtbStrength, useCloseValues, showOscillator, useOldTrend, ignoreInsideBars, useBreakouts);
		}

		public Indicators.PriceActionSwing.PriceActionSwingPro PriceActionSwingPro(ISeries<double> input , SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, AbcPatternMode abcPattern, DivergenceMode divergenceIndicatorMode, DivergenceDirection divergenceDirectionMode, int param1, int param2, int param3, bool showNakedSwings, bool addSwingExtension, bool addSwingRetracementFast, bool addSwingRetracementSlow, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool showSwingSwitch, int swingSwitchOffsetInTicks, DashStyleHelper abcLineStyle, DashStyleHelper abcLineStyleRatio, int abcLineWidth, int abcLineWidthRatio, NinjaTrader.Gui.Tools.SimpleFont abcTextFont, int abcTextOffsetLabel, double abcMaxRetracement, double abcMinRetracement, DashStyleHelper entryLineStyle, int entryLineWidth, double retracementEntryValue, bool showEntryArrows, bool showHistoricalEntryLine, int yTickOffset, bool showDivergenceRegular, bool showDivergenceHidden, DashStyleHelper divDnLineStyle, DashStyleHelper divUpLineStyle, int divDnLineWidth, int divUpLineWidth, bool showHistoricalNakedSwings, DashStyleHelper nakedSwingDashStyle, int nakedSwingLineWidth, bool ignoreInsideBars, bool useBreakouts, bool alertAbc, bool alertAbcEntry, Priority alertAbcPriority, Priority alertAbcEntryPriority, string alertAbcLongSoundFileName, string alertAbcLongEntrySoundFileName, string alertAbcShortSoundFileName, string alertAbcShortEntrySoundFileName, bool alertDoubleBottom, Priority alertDoubleBottomPriority, string alertDoubleBottomMessage, string alertDoubleBottomSoundFileName, int alertDoubleBottomRearmSeconds, bool alertDoubleTop, Priority alertDoubleTopPriority, string alertDoubleTopMessage, string alertDoubleTopSoundFileName, int alertDoubleTopRearmSeconds, bool alertHigherLow, Priority alertHigherLowPriority, string alertHigherLowMessage, string alertHigherLowSoundFileName, int alertHigherLowRearmSeconds, bool alertLowerHigh, Priority alertLowerHighPriority, string alertLowerHighMessage, string alertLowerHighSoundFileName, int alertLowerHighRearmSeconds, bool alertSwingChange, Priority alertSwingChangePriority, string alertSwingChangeMessage, string alertSwingChangeSoundFileName, int alertSwingChangeRearmSeconds, bool alertDivergenceRegularHigh, Priority alertDivergenceRegularHighPriority, string alertDivergenceRegularHighMessage, string alertDivergenceRegularHighSoundFileName, int alertDivergenceRegularHighRearmSeconds, bool alertDivergenceHiddenHigh, Priority alertDivergenceHiddenHighPriority, string alertDivergenceHiddenHighMessage, string alertDivergenceHiddenHighSoundFileName, int alertDivergenceHiddenHighRearmSeconds, bool alertDivergenceRegularLow, Priority alertDivergenceRegularLowPriority, string alertDivergenceRegularLowMessage, string alertDivergenceRegularLowSoundFileName, int alertDivergenceRegularLowRearmSeconds, bool alertDivergenceHiddenLow, Priority alertDivergenceHiddenLowPriority, string alertDivergenceHiddenLowMessage, string alertDivergenceHiddenLowSoundFileName, int alertDivergenceHiddenLowRearmSeconds)
		{
			return indicator.PriceActionSwingPro(input, swingType, swingSize, dtbStrength, useCloseValues, abcPattern, divergenceIndicatorMode, divergenceDirectionMode, param1, param2, param3, showNakedSwings, addSwingExtension, addSwingRetracementFast, addSwingRetracementSlow, swingLengthType, swingDurationType, showSwingPrice, showSwingLabel, showSwingPercent, swingTimeType, swingVolumeType, visualizationType, textFont, textOffsetLength, textOffsetVolume, textOffsetPrice, textOffsetLabel, textOffsetTime, textOffsetPercent, zigZagStyle, zigZagWidth, showSwingSwitch, swingSwitchOffsetInTicks, abcLineStyle, abcLineStyleRatio, abcLineWidth, abcLineWidthRatio, abcTextFont, abcTextOffsetLabel, abcMaxRetracement, abcMinRetracement, entryLineStyle, entryLineWidth, retracementEntryValue, showEntryArrows, showHistoricalEntryLine, yTickOffset, showDivergenceRegular, showDivergenceHidden, divDnLineStyle, divUpLineStyle, divDnLineWidth, divUpLineWidth, showHistoricalNakedSwings, nakedSwingDashStyle, nakedSwingLineWidth, ignoreInsideBars, useBreakouts, alertAbc, alertAbcEntry, alertAbcPriority, alertAbcEntryPriority, alertAbcLongSoundFileName, alertAbcLongEntrySoundFileName, alertAbcShortSoundFileName, alertAbcShortEntrySoundFileName, alertDoubleBottom, alertDoubleBottomPriority, alertDoubleBottomMessage, alertDoubleBottomSoundFileName, alertDoubleBottomRearmSeconds, alertDoubleTop, alertDoubleTopPriority, alertDoubleTopMessage, alertDoubleTopSoundFileName, alertDoubleTopRearmSeconds, alertHigherLow, alertHigherLowPriority, alertHigherLowMessage, alertHigherLowSoundFileName, alertHigherLowRearmSeconds, alertLowerHigh, alertLowerHighPriority, alertLowerHighMessage, alertLowerHighSoundFileName, alertLowerHighRearmSeconds, alertSwingChange, alertSwingChangePriority, alertSwingChangeMessage, alertSwingChangeSoundFileName, alertSwingChangeRearmSeconds, alertDivergenceRegularHigh, alertDivergenceRegularHighPriority, alertDivergenceRegularHighMessage, alertDivergenceRegularHighSoundFileName, alertDivergenceRegularHighRearmSeconds, alertDivergenceHiddenHigh, alertDivergenceHiddenHighPriority, alertDivergenceHiddenHighMessage, alertDivergenceHiddenHighSoundFileName, alertDivergenceHiddenHighRearmSeconds, alertDivergenceRegularLow, alertDivergenceRegularLowPriority, alertDivergenceRegularLowMessage, alertDivergenceRegularLowSoundFileName, alertDivergenceRegularLowRearmSeconds, alertDivergenceHiddenLow, alertDivergenceHiddenLowPriority, alertDivergenceHiddenLowMessage, alertDivergenceHiddenLowSoundFileName, alertDivergenceHiddenLowRearmSeconds);
		}

		public Indicators.ZTraderInd.GIndicatorProxy GIndicatorProxy(ISeries<double> input , GStrategyBase gSZTrader)
		{
			return indicator.GIndicatorProxy(input, gSZTrader);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.GIAwesomeOscillator GIAwesomeOscillator(int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType, bool showLines)
		{
			return indicator.GIAwesomeOscillator(Input, fastPeriod, slowPeriod, smooth, movingAverageType, showLines);
		}

		public Indicators.GIEMA GIEMA(int period, int offsetTicks)
		{
			return indicator.GIEMA(Input, period, offsetTicks);
		}

		public Indicators.GIFibonacci GIFibonacci(int param1)
		{
			return indicator.GIFibonacci(Input, param1);
		}

		public Indicators.GIGetHighLowByPeriod GIGetHighLowByPeriod(SignalBarByType periodStartBy, SignalBarByType periodEndBy, int startHour, int startMinute, int endHour, int endMinute)
		{
			return indicator.GIGetHighLowByPeriod(Input, periodStartBy, periodEndBy, startHour, startMinute, endHour, endMinute);
		}

		public Indicators.GIGetHighLowByTimeRange GIGetHighLowByTimeRange(int startHour, int startMinute, int endHour, int endMinute)
		{
			return indicator.GIGetHighLowByTimeRange(Input, startHour, startMinute, endHour, endMinute);
		}

		public Indicators.GIHLnBars GIHLnBars(int period)
		{
			return indicator.GIHLnBars(Input, period);
		}

		public Indicators.GIKAMA GIKAMA(int fast, int period, int slow)
		{
			return indicator.GIKAMA(Input, fast, period, slow);
		}

		public Indicators.GIKeyReversal GIKeyReversal(int periodLeft, int periodRight)
		{
			return indicator.GIKeyReversal(Input, periodLeft, periodRight);
		}

		public Indicators.GIMktCtx GIMktCtx(int ctxFilePath)
		{
			return indicator.GIMktCtx(Input, ctxFilePath);
		}

		public Indicators.GINBarsUpDn GINBarsUpDn(int barCount, bool barUp, bool higherHigh, bool higherLow, bool barDown, bool lowerHigh, bool lowerLow)
		{
			return indicator.GINBarsUpDn(Input, barCount, barUp, higherHigh, higherLow, barDown, lowerHigh, lowerLow);
		}

		public Indicators.GINetChg GINetChg(Cbi.PerformanceUnit unit, NetChgPosition location)
		{
			return indicator.GINetChg(Input, unit, location);
		}

		public Indicators.GIPbSAR GIPbSAR(double acceleration, double accelerationMax, double accelerationStep)
		{
			return indicator.GIPbSAR(Input, acceleration, accelerationMax, accelerationStep);
		}

		public Indicators.GIPctSpd GIPctSpd(int rocPeriod)
		{
			return indicator.GIPctSpd(Input, rocPeriod);
		}

		public Indicators.GIPriorMonthOHLC GIPriorMonthOHLC()
		{
			return indicator.GIPriorMonthOHLC(Input);
		}

		public Indicators.GIPriorWeekOHLC GIPriorWeekOHLC()
		{
			return indicator.GIPriorWeekOHLC(Input);
		}

		public Indicators.GISMI GISMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod, int sMICrossLevel)
		{
			return indicator.GISMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod, sMICrossLevel);
		}

		public Indicators.GISnR GISnR(bool showOvernightHL, bool showOpenHL, bool showLastdayHL, bool showLastdayClose, bool showTodayOpen, int timeOpen, int timeClose)
		{
			return indicator.GISnR(Input, showOvernightHL, showOpenHL, showLastdayHL, showLastdayClose, showTodayOpen, timeOpen, timeClose);
		}

		public Indicators.GISnRPriorWM GISnRPriorWM(bool showWkClose, bool showWkHigh, bool showWkLow, bool showWkOpen, bool showMoClose, bool showMoHigh, bool showMoLow, bool showMoOpen)
		{
			return indicator.GISnRPriorWM(Input, showWkClose, showWkHigh, showWkLow, showWkOpen, showMoClose, showMoHigh, showMoLow, showMoOpen);
		}

		public Indicators.GIVOL GIVOL(int volPeriod, int volWPRPeriod)
		{
			return indicator.GIVOL(Input, volPeriod, volWPRPeriod);
		}

		public Indicators.GIVWAP GIVWAP()
		{
			return indicator.GIVWAP(Input);
		}

		public Indicators.SMI SMI(int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.SMI(Input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

		public Indicators.PriceActionSwing.PriceActionSwing PriceActionSwing(SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool ignoreInsideBars, bool useBreakouts)
		{
			return indicator.PriceActionSwing(Input, swingType, swingSize, dtbStrength, useCloseValues, swingLengthType, swingDurationType, showSwingPrice, showSwingLabel, showSwingPercent, swingTimeType, swingVolumeType, visualizationType, textFont, textOffsetLength, textOffsetVolume, textOffsetPrice, textOffsetLabel, textOffsetTime, textOffsetPercent, zigZagStyle, zigZagWidth, ignoreInsideBars, useBreakouts);
		}

		public Indicators.PriceActionSwing.PriceActionSwingOscillator PriceActionSwingOscillator(SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, Show showOscillator, bool useOldTrend, bool ignoreInsideBars, bool useBreakouts)
		{
			return indicator.PriceActionSwingOscillator(Input, swingType, swingSize, dtbStrength, useCloseValues, showOscillator, useOldTrend, ignoreInsideBars, useBreakouts);
		}

		public Indicators.PriceActionSwing.PriceActionSwingPro PriceActionSwingPro(SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, AbcPatternMode abcPattern, DivergenceMode divergenceIndicatorMode, DivergenceDirection divergenceDirectionMode, int param1, int param2, int param3, bool showNakedSwings, bool addSwingExtension, bool addSwingRetracementFast, bool addSwingRetracementSlow, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool showSwingSwitch, int swingSwitchOffsetInTicks, DashStyleHelper abcLineStyle, DashStyleHelper abcLineStyleRatio, int abcLineWidth, int abcLineWidthRatio, NinjaTrader.Gui.Tools.SimpleFont abcTextFont, int abcTextOffsetLabel, double abcMaxRetracement, double abcMinRetracement, DashStyleHelper entryLineStyle, int entryLineWidth, double retracementEntryValue, bool showEntryArrows, bool showHistoricalEntryLine, int yTickOffset, bool showDivergenceRegular, bool showDivergenceHidden, DashStyleHelper divDnLineStyle, DashStyleHelper divUpLineStyle, int divDnLineWidth, int divUpLineWidth, bool showHistoricalNakedSwings, DashStyleHelper nakedSwingDashStyle, int nakedSwingLineWidth, bool ignoreInsideBars, bool useBreakouts, bool alertAbc, bool alertAbcEntry, Priority alertAbcPriority, Priority alertAbcEntryPriority, string alertAbcLongSoundFileName, string alertAbcLongEntrySoundFileName, string alertAbcShortSoundFileName, string alertAbcShortEntrySoundFileName, bool alertDoubleBottom, Priority alertDoubleBottomPriority, string alertDoubleBottomMessage, string alertDoubleBottomSoundFileName, int alertDoubleBottomRearmSeconds, bool alertDoubleTop, Priority alertDoubleTopPriority, string alertDoubleTopMessage, string alertDoubleTopSoundFileName, int alertDoubleTopRearmSeconds, bool alertHigherLow, Priority alertHigherLowPriority, string alertHigherLowMessage, string alertHigherLowSoundFileName, int alertHigherLowRearmSeconds, bool alertLowerHigh, Priority alertLowerHighPriority, string alertLowerHighMessage, string alertLowerHighSoundFileName, int alertLowerHighRearmSeconds, bool alertSwingChange, Priority alertSwingChangePriority, string alertSwingChangeMessage, string alertSwingChangeSoundFileName, int alertSwingChangeRearmSeconds, bool alertDivergenceRegularHigh, Priority alertDivergenceRegularHighPriority, string alertDivergenceRegularHighMessage, string alertDivergenceRegularHighSoundFileName, int alertDivergenceRegularHighRearmSeconds, bool alertDivergenceHiddenHigh, Priority alertDivergenceHiddenHighPriority, string alertDivergenceHiddenHighMessage, string alertDivergenceHiddenHighSoundFileName, int alertDivergenceHiddenHighRearmSeconds, bool alertDivergenceRegularLow, Priority alertDivergenceRegularLowPriority, string alertDivergenceRegularLowMessage, string alertDivergenceRegularLowSoundFileName, int alertDivergenceRegularLowRearmSeconds, bool alertDivergenceHiddenLow, Priority alertDivergenceHiddenLowPriority, string alertDivergenceHiddenLowMessage, string alertDivergenceHiddenLowSoundFileName, int alertDivergenceHiddenLowRearmSeconds)
		{
			return indicator.PriceActionSwingPro(Input, swingType, swingSize, dtbStrength, useCloseValues, abcPattern, divergenceIndicatorMode, divergenceDirectionMode, param1, param2, param3, showNakedSwings, addSwingExtension, addSwingRetracementFast, addSwingRetracementSlow, swingLengthType, swingDurationType, showSwingPrice, showSwingLabel, showSwingPercent, swingTimeType, swingVolumeType, visualizationType, textFont, textOffsetLength, textOffsetVolume, textOffsetPrice, textOffsetLabel, textOffsetTime, textOffsetPercent, zigZagStyle, zigZagWidth, showSwingSwitch, swingSwitchOffsetInTicks, abcLineStyle, abcLineStyleRatio, abcLineWidth, abcLineWidthRatio, abcTextFont, abcTextOffsetLabel, abcMaxRetracement, abcMinRetracement, entryLineStyle, entryLineWidth, retracementEntryValue, showEntryArrows, showHistoricalEntryLine, yTickOffset, showDivergenceRegular, showDivergenceHidden, divDnLineStyle, divUpLineStyle, divDnLineWidth, divUpLineWidth, showHistoricalNakedSwings, nakedSwingDashStyle, nakedSwingLineWidth, ignoreInsideBars, useBreakouts, alertAbc, alertAbcEntry, alertAbcPriority, alertAbcEntryPriority, alertAbcLongSoundFileName, alertAbcLongEntrySoundFileName, alertAbcShortSoundFileName, alertAbcShortEntrySoundFileName, alertDoubleBottom, alertDoubleBottomPriority, alertDoubleBottomMessage, alertDoubleBottomSoundFileName, alertDoubleBottomRearmSeconds, alertDoubleTop, alertDoubleTopPriority, alertDoubleTopMessage, alertDoubleTopSoundFileName, alertDoubleTopRearmSeconds, alertHigherLow, alertHigherLowPriority, alertHigherLowMessage, alertHigherLowSoundFileName, alertHigherLowRearmSeconds, alertLowerHigh, alertLowerHighPriority, alertLowerHighMessage, alertLowerHighSoundFileName, alertLowerHighRearmSeconds, alertSwingChange, alertSwingChangePriority, alertSwingChangeMessage, alertSwingChangeSoundFileName, alertSwingChangeRearmSeconds, alertDivergenceRegularHigh, alertDivergenceRegularHighPriority, alertDivergenceRegularHighMessage, alertDivergenceRegularHighSoundFileName, alertDivergenceRegularHighRearmSeconds, alertDivergenceHiddenHigh, alertDivergenceHiddenHighPriority, alertDivergenceHiddenHighMessage, alertDivergenceHiddenHighSoundFileName, alertDivergenceHiddenHighRearmSeconds, alertDivergenceRegularLow, alertDivergenceRegularLowPriority, alertDivergenceRegularLowMessage, alertDivergenceRegularLowSoundFileName, alertDivergenceRegularLowRearmSeconds, alertDivergenceHiddenLow, alertDivergenceHiddenLowPriority, alertDivergenceHiddenLowMessage, alertDivergenceHiddenLowSoundFileName, alertDivergenceHiddenLowRearmSeconds);
		}

		public Indicators.ZTraderInd.GIndicatorProxy GIndicatorProxy(GStrategyBase gSZTrader)
		{
			return indicator.GIndicatorProxy(Input, gSZTrader);
		}


		
		public Indicators.GIAwesomeOscillator GIAwesomeOscillator(ISeries<double> input , int fastPeriod, int slowPeriod, int smooth, MovingAvgType movingAverageType, bool showLines)
		{
			return indicator.GIAwesomeOscillator(input, fastPeriod, slowPeriod, smooth, movingAverageType, showLines);
		}

		public Indicators.GIEMA GIEMA(ISeries<double> input , int period, int offsetTicks)
		{
			return indicator.GIEMA(input, period, offsetTicks);
		}

		public Indicators.GIFibonacci GIFibonacci(ISeries<double> input , int param1)
		{
			return indicator.GIFibonacci(input, param1);
		}

		public Indicators.GIGetHighLowByPeriod GIGetHighLowByPeriod(ISeries<double> input , SignalBarByType periodStartBy, SignalBarByType periodEndBy, int startHour, int startMinute, int endHour, int endMinute)
		{
			return indicator.GIGetHighLowByPeriod(input, periodStartBy, periodEndBy, startHour, startMinute, endHour, endMinute);
		}

		public Indicators.GIGetHighLowByTimeRange GIGetHighLowByTimeRange(ISeries<double> input , int startHour, int startMinute, int endHour, int endMinute)
		{
			return indicator.GIGetHighLowByTimeRange(input, startHour, startMinute, endHour, endMinute);
		}

		public Indicators.GIHLnBars GIHLnBars(ISeries<double> input , int period)
		{
			return indicator.GIHLnBars(input, period);
		}

		public Indicators.GIKAMA GIKAMA(ISeries<double> input , int fast, int period, int slow)
		{
			return indicator.GIKAMA(input, fast, period, slow);
		}

		public Indicators.GIKeyReversal GIKeyReversal(ISeries<double> input , int periodLeft, int periodRight)
		{
			return indicator.GIKeyReversal(input, periodLeft, periodRight);
		}

		public Indicators.GIMktCtx GIMktCtx(ISeries<double> input , int ctxFilePath)
		{
			return indicator.GIMktCtx(input, ctxFilePath);
		}

		public Indicators.GINBarsUpDn GINBarsUpDn(ISeries<double> input , int barCount, bool barUp, bool higherHigh, bool higherLow, bool barDown, bool lowerHigh, bool lowerLow)
		{
			return indicator.GINBarsUpDn(input, barCount, barUp, higherHigh, higherLow, barDown, lowerHigh, lowerLow);
		}

		public Indicators.GINetChg GINetChg(ISeries<double> input , Cbi.PerformanceUnit unit, NetChgPosition location)
		{
			return indicator.GINetChg(input, unit, location);
		}

		public Indicators.GIPbSAR GIPbSAR(ISeries<double> input , double acceleration, double accelerationMax, double accelerationStep)
		{
			return indicator.GIPbSAR(input, acceleration, accelerationMax, accelerationStep);
		}

		public Indicators.GIPctSpd GIPctSpd(ISeries<double> input , int rocPeriod)
		{
			return indicator.GIPctSpd(input, rocPeriod);
		}

		public Indicators.GIPriorMonthOHLC GIPriorMonthOHLC(ISeries<double> input )
		{
			return indicator.GIPriorMonthOHLC(input);
		}

		public Indicators.GIPriorWeekOHLC GIPriorWeekOHLC(ISeries<double> input )
		{
			return indicator.GIPriorWeekOHLC(input);
		}

		public Indicators.GISMI GISMI(ISeries<double> input , int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod, int sMICrossLevel)
		{
			return indicator.GISMI(input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod, sMICrossLevel);
		}

		public Indicators.GISnR GISnR(ISeries<double> input , bool showOvernightHL, bool showOpenHL, bool showLastdayHL, bool showLastdayClose, bool showTodayOpen, int timeOpen, int timeClose)
		{
			return indicator.GISnR(input, showOvernightHL, showOpenHL, showLastdayHL, showLastdayClose, showTodayOpen, timeOpen, timeClose);
		}

		public Indicators.GISnRPriorWM GISnRPriorWM(ISeries<double> input , bool showWkClose, bool showWkHigh, bool showWkLow, bool showWkOpen, bool showMoClose, bool showMoHigh, bool showMoLow, bool showMoOpen)
		{
			return indicator.GISnRPriorWM(input, showWkClose, showWkHigh, showWkLow, showWkOpen, showMoClose, showMoHigh, showMoLow, showMoOpen);
		}

		public Indicators.GIVOL GIVOL(ISeries<double> input , int volPeriod, int volWPRPeriod)
		{
			return indicator.GIVOL(input, volPeriod, volWPRPeriod);
		}

		public Indicators.GIVWAP GIVWAP(ISeries<double> input )
		{
			return indicator.GIVWAP(input);
		}

		public Indicators.SMI SMI(ISeries<double> input , int eMAPeriod1, int eMAPeriod2, int range, int sMITMAPeriod)
		{
			return indicator.SMI(input, eMAPeriod1, eMAPeriod2, range, sMITMAPeriod);
		}

		public Indicators.PriceActionSwing.PriceActionSwing PriceActionSwing(ISeries<double> input , SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool ignoreInsideBars, bool useBreakouts)
		{
			return indicator.PriceActionSwing(input, swingType, swingSize, dtbStrength, useCloseValues, swingLengthType, swingDurationType, showSwingPrice, showSwingLabel, showSwingPercent, swingTimeType, swingVolumeType, visualizationType, textFont, textOffsetLength, textOffsetVolume, textOffsetPrice, textOffsetLabel, textOffsetTime, textOffsetPercent, zigZagStyle, zigZagWidth, ignoreInsideBars, useBreakouts);
		}

		public Indicators.PriceActionSwing.PriceActionSwingOscillator PriceActionSwingOscillator(ISeries<double> input , SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, Show showOscillator, bool useOldTrend, bool ignoreInsideBars, bool useBreakouts)
		{
			return indicator.PriceActionSwingOscillator(input, swingType, swingSize, dtbStrength, useCloseValues, showOscillator, useOldTrend, ignoreInsideBars, useBreakouts);
		}

		public Indicators.PriceActionSwing.PriceActionSwingPro PriceActionSwingPro(ISeries<double> input , SwingStyle swingType, double swingSize, int dtbStrength, bool useCloseValues, AbcPatternMode abcPattern, DivergenceMode divergenceIndicatorMode, DivergenceDirection divergenceDirectionMode, int param1, int param2, int param3, bool showNakedSwings, bool addSwingExtension, bool addSwingRetracementFast, bool addSwingRetracementSlow, SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, bool showSwingPrice, bool showSwingLabel, bool showSwingPercent, SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, VisualizationStyle visualizationType, NinjaTrader.Gui.Tools.SimpleFont textFont, int textOffsetLength, int textOffsetVolume, int textOffsetPrice, int textOffsetLabel, int textOffsetTime, int textOffsetPercent, DashStyleHelper zigZagStyle, int zigZagWidth, bool showSwingSwitch, int swingSwitchOffsetInTicks, DashStyleHelper abcLineStyle, DashStyleHelper abcLineStyleRatio, int abcLineWidth, int abcLineWidthRatio, NinjaTrader.Gui.Tools.SimpleFont abcTextFont, int abcTextOffsetLabel, double abcMaxRetracement, double abcMinRetracement, DashStyleHelper entryLineStyle, int entryLineWidth, double retracementEntryValue, bool showEntryArrows, bool showHistoricalEntryLine, int yTickOffset, bool showDivergenceRegular, bool showDivergenceHidden, DashStyleHelper divDnLineStyle, DashStyleHelper divUpLineStyle, int divDnLineWidth, int divUpLineWidth, bool showHistoricalNakedSwings, DashStyleHelper nakedSwingDashStyle, int nakedSwingLineWidth, bool ignoreInsideBars, bool useBreakouts, bool alertAbc, bool alertAbcEntry, Priority alertAbcPriority, Priority alertAbcEntryPriority, string alertAbcLongSoundFileName, string alertAbcLongEntrySoundFileName, string alertAbcShortSoundFileName, string alertAbcShortEntrySoundFileName, bool alertDoubleBottom, Priority alertDoubleBottomPriority, string alertDoubleBottomMessage, string alertDoubleBottomSoundFileName, int alertDoubleBottomRearmSeconds, bool alertDoubleTop, Priority alertDoubleTopPriority, string alertDoubleTopMessage, string alertDoubleTopSoundFileName, int alertDoubleTopRearmSeconds, bool alertHigherLow, Priority alertHigherLowPriority, string alertHigherLowMessage, string alertHigherLowSoundFileName, int alertHigherLowRearmSeconds, bool alertLowerHigh, Priority alertLowerHighPriority, string alertLowerHighMessage, string alertLowerHighSoundFileName, int alertLowerHighRearmSeconds, bool alertSwingChange, Priority alertSwingChangePriority, string alertSwingChangeMessage, string alertSwingChangeSoundFileName, int alertSwingChangeRearmSeconds, bool alertDivergenceRegularHigh, Priority alertDivergenceRegularHighPriority, string alertDivergenceRegularHighMessage, string alertDivergenceRegularHighSoundFileName, int alertDivergenceRegularHighRearmSeconds, bool alertDivergenceHiddenHigh, Priority alertDivergenceHiddenHighPriority, string alertDivergenceHiddenHighMessage, string alertDivergenceHiddenHighSoundFileName, int alertDivergenceHiddenHighRearmSeconds, bool alertDivergenceRegularLow, Priority alertDivergenceRegularLowPriority, string alertDivergenceRegularLowMessage, string alertDivergenceRegularLowSoundFileName, int alertDivergenceRegularLowRearmSeconds, bool alertDivergenceHiddenLow, Priority alertDivergenceHiddenLowPriority, string alertDivergenceHiddenLowMessage, string alertDivergenceHiddenLowSoundFileName, int alertDivergenceHiddenLowRearmSeconds)
		{
			return indicator.PriceActionSwingPro(input, swingType, swingSize, dtbStrength, useCloseValues, abcPattern, divergenceIndicatorMode, divergenceDirectionMode, param1, param2, param3, showNakedSwings, addSwingExtension, addSwingRetracementFast, addSwingRetracementSlow, swingLengthType, swingDurationType, showSwingPrice, showSwingLabel, showSwingPercent, swingTimeType, swingVolumeType, visualizationType, textFont, textOffsetLength, textOffsetVolume, textOffsetPrice, textOffsetLabel, textOffsetTime, textOffsetPercent, zigZagStyle, zigZagWidth, showSwingSwitch, swingSwitchOffsetInTicks, abcLineStyle, abcLineStyleRatio, abcLineWidth, abcLineWidthRatio, abcTextFont, abcTextOffsetLabel, abcMaxRetracement, abcMinRetracement, entryLineStyle, entryLineWidth, retracementEntryValue, showEntryArrows, showHistoricalEntryLine, yTickOffset, showDivergenceRegular, showDivergenceHidden, divDnLineStyle, divUpLineStyle, divDnLineWidth, divUpLineWidth, showHistoricalNakedSwings, nakedSwingDashStyle, nakedSwingLineWidth, ignoreInsideBars, useBreakouts, alertAbc, alertAbcEntry, alertAbcPriority, alertAbcEntryPriority, alertAbcLongSoundFileName, alertAbcLongEntrySoundFileName, alertAbcShortSoundFileName, alertAbcShortEntrySoundFileName, alertDoubleBottom, alertDoubleBottomPriority, alertDoubleBottomMessage, alertDoubleBottomSoundFileName, alertDoubleBottomRearmSeconds, alertDoubleTop, alertDoubleTopPriority, alertDoubleTopMessage, alertDoubleTopSoundFileName, alertDoubleTopRearmSeconds, alertHigherLow, alertHigherLowPriority, alertHigherLowMessage, alertHigherLowSoundFileName, alertHigherLowRearmSeconds, alertLowerHigh, alertLowerHighPriority, alertLowerHighMessage, alertLowerHighSoundFileName, alertLowerHighRearmSeconds, alertSwingChange, alertSwingChangePriority, alertSwingChangeMessage, alertSwingChangeSoundFileName, alertSwingChangeRearmSeconds, alertDivergenceRegularHigh, alertDivergenceRegularHighPriority, alertDivergenceRegularHighMessage, alertDivergenceRegularHighSoundFileName, alertDivergenceRegularHighRearmSeconds, alertDivergenceHiddenHigh, alertDivergenceHiddenHighPriority, alertDivergenceHiddenHighMessage, alertDivergenceHiddenHighSoundFileName, alertDivergenceHiddenHighRearmSeconds, alertDivergenceRegularLow, alertDivergenceRegularLowPriority, alertDivergenceRegularLowMessage, alertDivergenceRegularLowSoundFileName, alertDivergenceRegularLowRearmSeconds, alertDivergenceHiddenLow, alertDivergenceHiddenLowPriority, alertDivergenceHiddenLowMessage, alertDivergenceHiddenLowSoundFileName, alertDivergenceHiddenLowRearmSeconds);
		}

		public Indicators.ZTraderInd.GIndicatorProxy GIndicatorProxy(ISeries<double> input , GStrategyBase gSZTrader)
		{
			return indicator.GIndicatorProxy(input, gSZTrader);
		}

	}
}

#endregion
